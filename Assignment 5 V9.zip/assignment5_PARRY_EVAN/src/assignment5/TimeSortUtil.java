package assignment5;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import assignment5.SortUtil;

public class TimeSortUtil {

	public static void main(String[] args) {

		long startTime, midPointTime, stopTime, secondStart, secondEnd;

		startTime = System.nanoTime();
		while ((System.nanoTime() - startTime) < 1000000000) {
		}

		integerComparator cmp = new integerComparator();

		int maxLength = 100000;

		// ArrayList<Integer> bestCase = SortUtil.generateBestCase(maxLength);
		ArrayList<Integer> averageCase = SortUtil.generateAverageCase(maxLength);
		// ArrayList<Integer> worstCase = SortUtil.generateWorstCase(maxLength);

		int timesToLoop = 25;
		int counter = 0;

		for (int N = 100; N <= maxLength; N += 100) {

			// ArrayList<Integer> currentBest = new ArrayList<>();
			// ArrayList<Integer> currentAverage = new ArrayList<>();
			// ArrayList<Integer> currentWorst = new ArrayList<>();

			ArrayList<Integer> testArr = new ArrayList<>();
			ArrayList<Integer> temp = new ArrayList<>();

			// currentBest.add(bestCase.get(i));
			// currentAverage.add(averageCase.get(i));
			// currentWorst.add(worstCase.get(i));
			testArr = SortUtil.generateAverageCase(N);
			
			for (int m = 0; m < testArr.size()-1; m++) {
				secondStart = System.nanoTime();
				temp.add(testArr.get(m));
				secondEnd = System.nanoTime();
				counter += (secondEnd - secondStart);
			}

			
				startTime = System.nanoTime();

				while ((System.nanoTime() - startTime) < 1000000000) {
				}

				for (int j = 0; j < timesToLoop; j++) {

					SortUtil.mergesort(temp, cmp);
				}

				midPointTime = System.nanoTime();

				for (long l = 0; l < timesToLoop; l++) {
				}

				stopTime = System.nanoTime();

//				for (long l = 0; l < timesToLoop; l++) {
//				}

				// stopTime = System.nanoTime();

				double averageTime = (((midPointTime - startTime) - (stopTime - midPointTime)) / timesToLoop);

				System.out.println(N + "\t" + averageTime);
			

		}

	}
}

class integerComparator implements Comparator<Integer> {
	public int compare(Integer o1, Integer o2) {
		return o1.compareTo(o2);
	}
}
