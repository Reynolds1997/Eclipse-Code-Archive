package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

public class TimeSortUtil {

	public static void main(String[] args) {

		IntegerComparator cmp = new IntegerComparator();
		long midPointTime;

		long startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000) {

		}

		long stopTime = 0;
		long secondStop = 0;
		long secondStart = 0;
		long subTime = 0;
		int timesToLoop = 25;

		for (int N = 50; N >= 1; N--) {
			int size = N *N ;
			ArrayList<Integer> testArr = SortUtil.generateWorstCase(size);
			ArrayList<Integer> temp = new ArrayList<>();

			startTime = System.nanoTime();

			for (int j = 0; j <= timesToLoop; j++) {

				secondStart = System.nanoTime();

				for (int i = 0; i < testArr.size(); i++) {
					temp.add(testArr.get(i));
				}
				secondStop = System.nanoTime();

				SortUtil.quicksort(temp, cmp);

			}

			midPointTime = System.nanoTime();

			for (long k = 0; k <= timesToLoop; k++) {

			}

			stopTime = System.nanoTime();
			subTime = (secondStop - secondStart);

			double averageTime = (double) ((midPointTime - startTime) - (stopTime - midPointTime) - subTime)
					/ timesToLoop;
			
			System.out.println(size + "\t" + averageTime);
		}

	}

	static class IntegerComparator implements Comparator<Integer> {

		@Override
		public int compare(Integer arg0, Integer arg1) {
			// TODO Auto-generated method stub
			return (arg0.compareTo(arg1));
		}

	}

}
