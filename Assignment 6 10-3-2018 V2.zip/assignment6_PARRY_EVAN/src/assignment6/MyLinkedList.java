package assignment6;

import java.util.NoSuchElementException;

public class MyLinkedList<T> implements List<T> {

	private Node head = null;
	private Node tail = null;
	private int size = 0;

	private class Node {

		T element;
		Node next;
		Node previous;

		Node(T data) {
			element = data;
			next = null;
			previous = null;
		}
	}

	public MyLinkedList() {
		//Ask about filling this.
	}

	public Node getNode(int index) {
		Node curr;
		if (index < (size / 2)) {
			curr = head;
			for (int i = 0; i < index; i++) {
				curr = curr.next;
			}
		} else {
			curr = tail;
			for (int j = size - 1; j > index; j--) {
				curr = curr.previous;
			}
		}
		return curr;
	}
	
	
	@Override
	public void addFirst(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size > 0) {
			newNode.next = head;
			head.previous = newNode;
		}

		else if (size == 0) {
			tail = newNode;
		}

		// Make sure that the new head's .previous is pointing to null
		head = newNode;
		newNode.previous = null;

		size++;
	}

	@Override
	public void addLast(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size == 0) {
			addFirst(element);
		} else {
			newNode.previous = tail;
			tail.next = newNode;

			// Make sure that the new tail's .next is pointing to null

			tail = newNode;
			newNode.next = null;
			size++;
		}
	}

	@Override
	public void add(int index, T element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}

		if (index == 0) {
			addFirst(element);
		}
		else if (index == size) {
			addLast(element);
		}
		else {

		Node newNode = new Node(element);

		Node curr = getNode(index);
		
		newNode.previous = curr.previous;
		newNode.next = curr;
		curr.previous.next = newNode;
		curr.previous = newNode;

		size++;
		}
	}

	@Override
	public T getFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return head.element;
	}

	@Override
	public T getLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return tail.element;
	}

	@Override
	public T get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}

		Node curr = getNode(index);
		return curr.element;
//		if (index < (size / 2)) {
//			Node temp = head;
//
//			for (int i = 0; i < index; i++) {
//				temp = temp.next;
//			}
//			return temp.element;
//		} else {
//			Node temp = tail;
//
//			for (int j = size - 1; j > index; j++) {
//				temp = temp.previous;
//			}
//			return temp.element;
//		}

	}

	@Override
	public T removeFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		Node tempHead = head;
		head.next = head;
		head.previous = null;
		size--;
		return tempHead.element;
	}

	@Override
	public T removeLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		Node tempTail = tail;
		tail.previous = tail;
		tail.next = null;
		size--;
		return tempTail.element;
		
	}

	@Override
	public T remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			return removeFirst();
		}
		else if (index == size - 1) {
			return removeLast();
		}
		else {
		Node removeNode = getNode(index);
		
		removeNode.previous.next = removeNode.next;
		removeNode.next.previous = removeNode.previous;
		size--;
		return removeNode.element;
		}
	}

	@Override
	public int indexOf(T element) {
		// TODO Auto-generated method stub

		
		Node temp = head;

		for (int i = 0; i < size; i++) {
			if (temp.element.equals(element)) {
				return i;
			}
			temp = temp.next;
		}
		return -1;
	}

	@Override
	public int lastIndexOf(T element) {
		// TODO Auto-generated method stub
		Node temp = tail;
		
		for (int i = size - 1; i >= 0; i--) {
			if (temp.element.equals(element)) {
				return i;
			}
			temp = temp.previous;
		}
		return -1;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		head = null;
		tail = null;
		size = 0;
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		Object[] newArray = new Object[size+1];
		
		Node temp = head;
		for(int i = 0; i < size; i ++) {
			newArray[i] = temp.element;
			temp = temp.next;
		}
		
		return newArray;
	}

}
