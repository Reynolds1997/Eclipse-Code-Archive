package assignment6;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyLinkedListTest {

//	@Test
//	public void testGetNode() {
//		fail("Not yet implemented");
//	}
	
	@Test
	public void testAddFirst() {
		MyLinkedList<String> test = new MyLinkedList<String>();
		test.addFirst("Adam");
		
//		System.out.println(test.get(0));
//		test.addFirst("Bryan");
//		System.out.println(test.get(0));
//		
//		System.out.println(test.get(1));
	}

	@Test
	public void testAddLast() {
		MyLinkedList<String> test = new MyLinkedList<String>();
		test.addLast("Adam");
		
//		System.out.println(test.get(0));
//		test.addLast("Bryan");
//		System.out.println(test.get(1));
//		
//		System.out.println(test.get(0));
	}
	
	@Test
	public void testAdd() {
		MyLinkedList<String> test = new MyLinkedList<String>();
		test.addFirst("Charlie");
		test.addFirst("Bethany");
		test.addFirst("Danielle");
		
//		System.out.println(test.get(0));
//		System.out.println(test.get(1));
//		System.out.println(test.get(2));
//
//		System.out.println("Adding Ethan to index 1: ");
//		test.add(1, "Ethan");
//		
//		System.out.println(test.get(0));
//		System.out.println(test.get(1));
//		System.out.println(test.get(2));
//		System.out.println(test.get(3));

	}
	
	@Test
	public void testGetFirst() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		
		//System.out.println(test.getFirst());
	}
	
	@Test
	public void testGetLast() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		
	//	System.out.println(test.getLast());
	}
	
	@Test
	public void testGet() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		test.addFirst("Tina");
		
	//	System.out.println(test.get(1));
	}
	
	@Test
	public void testRemoveFirst() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		test.addFirst("Tina");
		
	//	System.out.println(test.removeFirst());
	}
	
	@Test
	public void testRemoveLast() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		test.addFirst("Tina");
		
	//	System.out.println(test.removeLast());
	}
	
	@Test
	public void testRemove() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addFirst("Sally");
		test.addFirst("Tina");
		
	//	System.out.println(test.remove(1));
	}
	
	@Test
	public void testIndexOf() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addLast("Sally");
		test.add(1, "Tina");
		test.add(1, "Sally");
		
//		System.out.println(test.get(0));
//		System.out.println(test.get(1));
//		System.out.println(test.get(2));
//		System.out.println(test.get(3));
//	
//		System.out.println(test.indexOf("Ramon"));
	}
	
	@Test
	public void testLastIndexOf() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addLast("Sally");
		test.add(1, "Tina");
		test.add(1, "Sally");
		
		// ramon sally tina sally
		
	//	System.out.println(test.lastIndexOf("Sally"));
	}
	
	@Test
	public void testSize() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addLast("Sally");
		test.add(1, "Tina");
		test.add(1, "Sally");
		
//		System.out.println(test.size());
//		
//		test.remove(3);
//		System.out.println(test.size());
	}
	
	@Test
	public void testIsEmpty() {
		MyLinkedList<String> test = new MyLinkedList<String>();

//		System.out.println(test.isEmpty());
//
//		test.addFirst("Ramon");
//		
//		System.out.println(test.isEmpty());
	}
	
	@Test
	public void testClear() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addLast("Sally");
		test.add(1, "Tina");
		test.add(1, "Sally");
		
//		test.clear();
//		System.out.println(test.isEmpty());
//		System.out.println(test.size());
	//	System.out.println(test.get(1));
		
//		
//		test.remove(3);
//		System.out.println(test.size());
	}
	
	@Test
	public void testToArray() {
		MyLinkedList<String> test = new MyLinkedList<String>();

		test.addFirst("Ramon");
		test.addLast("Sally");
		test.add(0, "Tina");
		test.add(1, "Sally");
		
		// Tina Sally Ramon Sally 
		
//		System.out.println(test.get(0));
//		System.out.println(test.get(1));
//		System.out.println(test.get(2));
//		System.out.println(test.get(3));
		
		
		//We need to check on the status of get, add, addFirst, etc.
		
//		System.out.println(test.getFirst());
		
		System.out.println("To Array: ");
		Object[] testArray = test.toArray();
		for(int i = 0; i < testArray.length -1; i++) {
			System.out.println(testArray[i]);
		}
	}
}
