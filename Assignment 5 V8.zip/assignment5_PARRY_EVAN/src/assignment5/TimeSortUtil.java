package assignment5;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import assignment5.SortUtil;

public class TimeSortUtil {
	
	private static Random rand;

	public static void main(String[] args) {
		rand = new Random();
		rand.setSeed(System.currentTimeMillis());

		long startTime, midPointTime, stopTime;

		startTime = System.nanoTime();

		while ((System.nanoTime() - startTime) < 1000000000) {
		}

		
		integerComparator cmp = new integerComparator();

		
		int maxLength = 100000;
		
	//	ArrayList<Integer> bestCase = SortUtil.generateBestCase(maxLength);
	//	ArrayList<Integer> averageCase = SortUtil.generateAverageCase(maxLength);
		ArrayList<Integer> worstCase = SortUtil.generateWorstCase(maxLength);

		int timesToLoop = 2500;

		for (int N = 1000; N <= maxLength; N += 1000) {
			
		//	ArrayList<Integer> currentBest = new ArrayList<>();
		//	ArrayList<Integer> currentAverage = new ArrayList<>();
			ArrayList<Integer> currentWorst = new ArrayList<>();
			
			for(int i = 0; i < N; i++) {
			//	currentBest.add(bestCase.get(i));
			//	currentAverage.add(averageCase.get(i));
				currentWorst.add(worstCase.get(i));
			}

			startTime = System.nanoTime();

			for (int j = 0; j < timesToLoop; j++) {
				
//				ArrayList<Integer> currentCopy = new ArrayList<>();
//				for(int k = 0; k < N; k++) {
//					currentCopy.add(currentBest.get(k));
//				}
				
				SortUtil.mergesort(currentWorst, cmp);
			}
			
			midPointTime = System.nanoTime();
			
			for (long l = 0; l < timesToLoop; l ++) {
			}
			
			stopTime = System.nanoTime();

//			double secondStartTime = System.nanoTime();
//			for(int m = 0; m < timesToLoop; m++) {
//				ArrayList<Integer> calibrateCopy = new ArrayList<>();
//				for(int n = 0; n < N; n++) {
//				calibrateCopy.add(currentBest.get(n));
//				}
//			}
//			double secondEndTime = System.nanoTime();
			
			double averageTime = (((midPointTime - startTime) - (stopTime - midPointTime))/ timesToLoop) ;
			
			System.out.println(N + "\t" + averageTime);

		}

	}

	static class charCompare implements Comparator<Character> {

		@Override
		public int compare(Character o1, Character o2) {
			return o1.compareTo(o2);
		}

	}

	static class integerComparator implements Comparator<Integer> {
		public int compare(Integer o1, Integer o2) {
			return o1.compareTo(o2);
		}
	}

	public static String randomString(int length) {
		String retval = "";
		for (int i = 0; i < length; i++) {
			// ASCII values a-z are contiguous (26 characters)
			retval += (char) ('a' + (rand.nextInt(26)));
		}
		return retval;
	}

}

