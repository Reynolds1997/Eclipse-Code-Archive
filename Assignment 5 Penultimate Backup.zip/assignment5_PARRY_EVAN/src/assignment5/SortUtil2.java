package assignment5;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

/**
 * 
 * @author Evan Parry and Andrew Fryzel This class used various methods to
 *         perform a mergesort and quicksort on passed in array values
 *
 */
public class SortUtil2 {

	private static int threshold = 10;

	/**
	 * This method is a driver method for performing a mergesort on the generic
	 * ArrayList given as input.
	 * 
	 * @param arr The array that will be Merge Sorted
	 * @param cmp A comparator that defines how items are compared
	 */
	public static <T> void mergesort(ArrayList<T> arr, Comparator<? super T> cmp) {
		ArrayList<T> temp = new ArrayList<T>(arr.size());

		mergeSortHelper(arr, temp, cmp, 0, arr.size() - 1);
	}

	/**
	 * This merge sort helper method determines when the sort is done, determines a
	 * threshhold to use an insertion sort and recursively calls itself and the
	 * merge() method
	 * 
	 * @param arr     The array to be sorted
	 * @param tempArr A temporary array to hold the temporary values of the merge.
	 * @param cmp     A comparator that defines how items will be compared
	 * @param start   The beginning index of the array
	 * @param end     The end index of the array
	 */
	public static <T> void mergeSortHelper(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start,
			int end) {

		if (arr.size() == 0 || arr == null)
			return;

		if (start >= end) {
			return;
		}
		// Check if arr.size works too
		if (arr.size()<= threshold)
			insertionSort(arr, cmp, start, end);

		// This we trigger when dataset is greater than threshold
		int mid = (start + end) / 2;
		mergeSortHelper(arr, tempArr, cmp, start, mid);
		mergeSortHelper(arr, tempArr, cmp, mid + 1, end);
		tempArr.clear();
		merge(arr, tempArr, cmp, start, mid, end);

	}

	/**
	 * This method merges two halves of a sorted list together. Takes in an array
	 * and stores the merge in a temporary array.
	 * 
	 * @param arr     The array to be sorted
	 * @param tempArr A temporary array to hold the temporary values of the merge.
	 * @param cmp     A comparator that defines how items will be compared
	 * @param start   The beginning index of the array
	 * @param mid     The middle of the array
	 * @param end     The end index of the array
	 */
	public static <T> void merge(ArrayList<T> arr, ArrayList<T> temp, Comparator<? super T> cmp, int start, int mid,
			int end) {
		int i = start;
		int i2 = mid + 1;

		while ((i <= mid) && (i2 <= end)) {
			if (cmp.compare(arr.get(i), arr.get(i2)) <= 0) {
				temp.add(arr.get(i));
				i++;
			} else {
				temp.add(arr.get(i2));
				i2++;
			}
		}

		while (i <= mid) {
			temp.add(arr.get(i));
			i++;
		}

		while (i2 <= end) {
			temp.add(arr.get(i));
			i2++;
			i++;
		}

		int j = 0;
		int k = start;
		while (j < temp.size()) {
			arr.set(k, temp.get(j));
			j++;
			k++;
		}
	}

	/**
	 * An insertion that is called during merge sort if the array reaches a certain
	 * threshold value
	 * 
	 * @param arr The array to be sorted
	 * @param cmp The comparator that determines the ordering
	 */
	public static <T> void insertionSort(ArrayList<T> arr, Comparator<? super T> cmp, int start, int end) {
	
		int i;
		T key;
		int j;

		for (i = start; i < end+1; i++) {
			key = arr.get(i);
			j = i - 1;

			while (j >= 0 && cmp.compare(arr.get(j), key) > 0) {
				arr.set(j + 1, arr.get(j));
				j--;
			}
			arr.set(j + 1, key);
		}
	}

	/**
	 * This driver method calls quickSortHelper on the generic ArrayList given as
	 * input to perform a quicksort.
	 * 
	 * @param arr The array that will be Quick Sorted
	 * @param cmp A comparator that defines how items are compared
	 */
	public static <T> void quicksort(ArrayList<T> arr, Comparator<? super T> cmp) {

		// pick an item to be our pivot (via selecting its index) i.e. arr.get(mid)
		// Swap that with the last item

		quickSortHelper(arr, cmp, 0, arr.size() - 1);
	}

	/**
	 * A helper method for the quickSort() method that performs a quick sort on the
	 * passed in array.
	 * 
	 * @param arr        The array to be sorted
	 * @param cmp        A comparator that defines how items will be compared
	 * @param leftBound  The beginning index of the array
	 * @param rightBound The end index of the array
	 */
	public static <T> void quickSortHelper(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {
		if (arr.size() == 0 || arr == null)
			return;

		if (rightBound <= leftBound) {
			return;
		}

		int index = partition(arr, cmp, leftBound, rightBound);

		// base case: leftbound > index-1 && rightBound < index
		quickSortHelper(arr, cmp, leftBound, index - 1);
		quickSortHelper(arr, cmp, index + 1, rightBound);
	}

	/**
	 * This method performs a quick sort on the passed in array.
	 * 
	 * @param arr        The array to be sorted
	 * @param cmp        A comparator that defines how items will be compared
	 * @param leftBound  The beginning index of the array
	 * @param rightBound The end index of the array
	 * @return The left value
	 */
	public static <T> int partition(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {

		//int pivot = halfPivot(leftBound, rightBound);
		// int pivot = randomMedianPivot(arr, cmp, leftBound, rightBound);
		 int pivot = randomAvgPivot(leftBound, rightBound);

		swapReferences(arr, pivot, rightBound);

		int left = leftBound;
		int right = rightBound - 1;

		// while(left < right){
		while (left <= right) {
			while (left < rightBound && cmp.compare(arr.get(left), arr.get(rightBound)) <= 0) {
				left++;
			}

			while (right > leftBound && cmp.compare(arr.get(right), arr.get(rightBound)) >= 0) {
				right--;
			}

			if (left <= right) {
				swapReferences(arr, left, right);
				right--;
			}
		}
		swapReferences(arr, left, rightBound);

		return left;
	}

	/**
	 * Generates a pivot within a given range by calculating the midpoint index
	 * between the left and right bounds.
	 * 
	 * @param leftBound  -- the left bound of the given range
	 * @param rightBound -- the right bound of the given range
	 * @return
	 */
	public static int halfPivot(int leftBound, int rightBound) {
		return (leftBound + rightBound) / 2;
	}

	/**
	 * @param arr        -- the input ArrayList
	 * @param cmp        -- a comparator for arr's type
	 * @param leftBound  -- the left bound of the given range
	 * @param rightBound -- the right bound of the given range
	 * @return the new pivot
	 */
	public static <T> int randomMedianPivot(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound,
			int rightBound) {
		Random rand = new Random();

		int indexOne = rand.nextInt((rightBound - leftBound) + 1) + leftBound;
		int indexTwo = rand.nextInt((rightBound - leftBound) + 1) + leftBound;
		int indexThree = rand.nextInt((rightBound - leftBound) + 1) + leftBound;

		if (cmp.compare(arr.get(indexOne), arr.get(indexTwo)) <= 0
				&& cmp.compare(arr.get(indexOne), arr.get(indexThree)) >= 0) {
			return indexOne;
		} else if (cmp.compare(arr.get(indexOne), arr.get(indexTwo)) >= 0
				&& cmp.compare(arr.get(indexOne), arr.get(indexThree)) <= 0) {
			return indexOne;
		} else if (cmp.compare(arr.get(indexTwo), arr.get(indexOne)) <= 0
				&& cmp.compare(arr.get(indexTwo), arr.get(indexThree)) >= 0) {
			return indexTwo;
		} else if (cmp.compare(arr.get(indexTwo), arr.get(indexOne)) >= 0
				&& cmp.compare(arr.get(indexTwo), arr.get(indexThree)) <= 0) {
			return indexTwo;
		} else if (cmp.compare(arr.get(indexThree), arr.get(indexOne)) <= 0
				&& cmp.compare(arr.get(indexThree), arr.get(indexTwo)) >= 0) {
			return indexThree;
		} else {
			return indexThree;
		}
	}

	/**
	 * Generates a random pivot index in a given range by generating three random
	 * index values within the range and computing the average of those values.
	 * 
	 * @param leftBound  -- the left bound of the given range
	 * @param rightBound -- the right bound of the given range
	 * @return the new pivot
	 */
	public static <T> int randomAvgPivot(int leftBound, int rightBound) {
		Random rand = new Random();

		int indexOne = rand.nextInt((rightBound - leftBound) + 1) + leftBound;
		int indexTwo = rand.nextInt((rightBound - leftBound) + 1) + leftBound;
		int indexThree = rand.nextInt((rightBound - leftBound) + 1) + leftBound;

		int result = (indexOne + indexTwo + indexThree) / 3;
		return result;
	}

	/**
	 * This method swaps to items with each other
	 * 
	 * @param arr   The array passed in and whose values will be adjusted
	 * @param left  The first value to be switched
	 * @param right The second value to be switched
	 */
	public static <T> void swapReferences(ArrayList<T> arr, int left, int right) {
		T temp = arr.get(left);

		arr.set(left, arr.get(right));
		arr.set(right, temp);
	}

	/**
	 * This method generates and returns an ArrayList of integers 1 to size in
	 * ascending order. Generates a "best case".
	 * 
	 * @param size The size of the number
	 * @return An arrayList of numbers
	 */
	public static ArrayList<Integer> generateBestCase(int size) {
		ArrayList<Integer> bestCase = new ArrayList<Integer>();
		for (int i = 1; i <= size; i++) {
			bestCase.add(i);
		}
		return bestCase;
	}

	/**
	 * Generates an average case ArrayList of integers by randomly permuting the
	 * items in an ArrayList of the given range.
	 * 
	 * @param size The size of the number
	 * @return An arrayList of numbers
	 */
	public static ArrayList<Integer> generateAverageCase(int size) {
		ArrayList<Integer> avgCase = new ArrayList<Integer>();

		Random rand = new Random();

		for (int i = 1; i <= size; i++) {
			avgCase.add(i);
		}
		for (int j = 0; j < avgCase.size() - 1; j++) {
			swapReferences(avgCase, j, rand.nextInt(avgCase.size() - 1));
		}

		return avgCase;
	}

	/**
	 * Generates a worst case ArrayList of integers. This method generates and
	 * returns an ArrayList of integers 1 to size in descending order.
	 * 
	 * @param size The size of the number
	 * @return An arrayList of numbers
	 */
	public static ArrayList<Integer> generateWorstCase(int size) {
		ArrayList<Integer> worstCase = new ArrayList<Integer>();

		for (int i = size; i > 0; i--) {
			worstCase.add(i);
		}
		return worstCase;
	}
}
