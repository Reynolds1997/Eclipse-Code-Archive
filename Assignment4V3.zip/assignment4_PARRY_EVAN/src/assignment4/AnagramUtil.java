package assignment4;

import java.util.Arrays;
import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class according to the specifications
 *
 */
public class AnagramUtil {

	// Go through this later and see if we can reuse

	// string.length refers to

	public static String sort(String input) {
		Character arr[] = new Character[input.length()];
		String output = "";
		

		for (int i = 0; i < input.length(); i++) {

			arr[i] = input.charAt(i);
		}

		charCompare cmp = new charCompare();

		insertionSort(arr, cmp);

		for (int j = 0; j < input.length(); j++) {
			output += arr[j];
		}

		// Check if this toString actually works
		return output;
	}

	public static <T> void insertionSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;
		int i;
		T key;
		int j;

		for (i = 1; i < stop; i++) {
			key = arr[i]; // Initializes key to currently compared value
			j = i - 1; // sets J to the index directly before index i

			while (j >= 0 && (cmp.compare(arr[j], key) > 0)) {
				arr[j + 1] = arr[j];
				j--;
			}
			arr[j + 1] = key;
		}
	}

	public static <T> void shellSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;

		// draw this out visually to help better understand the underlying process

		for (int gap = (stop / 2); gap > 0; gap /= 2) {

			for (int i = gap; i < stop; i += 1) {
				T temp = arr[i];
				int j;
				for (j = i; j >= gap && cmp.compare(arr[j - gap], temp) > 0; j -= gap) {
					arr[j] = arr[j - gap];
				}
				arr[j] = temp;
			}
		}

	}

	public static boolean areAnagrams(String string1, String string2) {

		string1 = string1.toLowerCase();
		string2 = string2.toLowerCase();
		
		if(string1 == null || string2 == null) {
			return false;
		}
				
		String inString1 = sort(string1);
		String inString2 = sort(string2);

		if (inString1.equals(inString2)) {
			return true;
		}
		return false;
	}

	public static String[] getLargestAnagramGroup(String[] array) {
//Do a null check in every method
		String[] arr = new String[array.length]; 
		//Edge Cases
		
		
		//Main program
		for (int i = 0; i < array.length; i++) {
			arr[i] = array[i];
		}

		for (int j = 0; j < arr.length; j++) {
			String input = arr[j];
			input = input.toLowerCase();
			arr[j] = sort(input);
		}
		
		if(array.length == 2) {
			if(areAnagrams(arr[0], arr[1])){
				String[] edgeArr = new String[2];
				
				edgeArr[0] = array[0];
				edgeArr[1] = array[1];
				return edgeArr;
			}
			else return null;
		}
		if(array.length == 1) {
			return array;
		}
		if(array.length == 0) {
			return null;
		}

		stringCompare cmp = new stringCompare();

		
		//Change this for time tests
		Arrays.sort(arr);

		int largestCounter = 1;
		int currentCounter = 1;

		String largestAnagram = "";

		for (int k = 0; k < arr.length - 1; k++) {

			if (areAnagrams(arr[k], arr[k + 1])) {
				// System.out.println(arr[j]);
				currentCounter++;
			} else { // if they aren't anagrams
				if (currentCounter > largestCounter) {
					largestCounter = currentCounter;
					largestAnagram = arr[k];
					currentCounter = 1;
					// System.out.println("Largest anagram " + largestAnagram);
				} else {
					currentCounter = 1;
				}
			}
		}

		String[] output = new String[largestCounter];
		int counter = 0;

		for (int l = 0; l < array.length; l++) {
			String testWord = array[l];
			if (areAnagrams(testWord, largestAnagram)) {
				// System.out.println(testWord);
				output[counter] = array[l];
				counter++;
			}
		}

		return output;
	}

	static class charCompare implements Comparator<Character> {

		@Override
		public int compare(Character o1, Character o2) {
			return o1.compareTo(o2);
		}

	}

	static class stringCompare implements Comparator<String> {

		@Override
		public int compare(String o1, String o2) {
			if (o1.compareTo(o2) < 0) {
				return -1;
			} else if (o1.compareTo(o2) > 0) {
				return 1;
			}
			return 0;
		}
	}
}
