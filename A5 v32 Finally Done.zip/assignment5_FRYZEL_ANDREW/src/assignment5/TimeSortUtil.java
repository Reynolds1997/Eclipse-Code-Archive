package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

public class TimeSortUtil {

	public static void main(String[] args) {

		IntegerComparator cmp = new IntegerComparator();
		long midPointTime;

		long startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000) {

		}

		long stopTime = 0;
		int size = 0;
		int timesToLoop = 2500;

		for (int N = 1000; N <= 20000; N += 1000) {
			size = N;
			ArrayList<Integer> testArr = new ArrayList<>(size);
			testArr.addAll(SortUtil.generateAverageCase(size));
//			testArr.addAll(SortUtil.generateWorstCase(size));
//			testArr.addAll(SortUtil.generateBestCase(size));
			startTime = System.nanoTime();

			for (int j = 0; j <= timesToLoop; j++) {


				ArrayList<Integer> temp = new ArrayList<Integer>(testArr);

				SortUtil.insertionSort(temp, cmp, 0, size - 1);
			 //SortUtil.mergesort(temp, cmp);


			}

			midPointTime = System.nanoTime();

			for (long k = 0; k <= timesToLoop; k++) {

				ArrayList<Integer> temp = new ArrayList<Integer>(testArr);

			}

			stopTime = System.nanoTime();

			double averageTime = ((midPointTime - startTime) - (stopTime - midPointTime)) / timesToLoop;
			System.out.println(size + "\t" + averageTime);
		}

	}

	static class IntegerComparator implements Comparator<Integer> {

		@Override
		public int compare(Integer arg0, Integer arg1) {
			// TODO Auto-generated method stub
			return (arg0.compareTo(arg1));
		}

	}

}
