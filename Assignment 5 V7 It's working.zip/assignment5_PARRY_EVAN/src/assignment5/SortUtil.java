package assignment5;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

/**
 * 
 * @author ?? Fill in this class as specified in the assignment5 instructions.
 *
 */
public class SortUtil {

	private static int threshold = 10;

	public static <T> void mergesort(ArrayList<T> arr, Comparator<? super T> cmp) {
		ArrayList<T> temp = new ArrayList<T>(arr.size());

//		for(int i = 0; i < arr.size(); i++) {
//			temp.add(null);
//		}

		mergeSortHelper(arr, temp, cmp, 0, arr.size() - 1);
	}

	public static <T> void mergeSortHelper(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start,
			int end) {

		if (start >= end) {
			return;
		}
		// Check if arr.size works too
		if ((end - start) <= threshold) {
			insertionSort(arr, cmp);
		} else {
			// This we trigger when dataset is greater than threshold
			int mid = (start + end) / 2;
			mergeSortHelper(arr, tempArr, cmp, start, mid);
			mergeSortHelper(arr, tempArr, cmp, mid + 1, end);
			tempArr.clear();
			merge(arr, tempArr, cmp, start, mid, end);
		}
	}

	public static <T> void merge(ArrayList<T> arr, ArrayList<T> temp, Comparator<? super T> cmp, int start, int mid,
			int end) {
		int i = start;
		int i2 = mid + 1;

		while ((i <= mid) && (i2 <= end)) {
			if (cmp.compare(arr.get(i), arr.get(i2)) <= 0) {
				temp.add(arr.get(i));
				i++;
			} else {
				temp.add(arr.get(i2));
				i2++;
			}
		}

		while (i <= mid) {
			temp.add(arr.get(i));
			i++;
		}

		while (i2 <= end) {
			temp.add(arr.get(i));
			i2++;
			i++;
		}

		int j = 0;
		int k = start;
		while (j < temp.size()) {
			arr.set(k, temp.get(j));
			j++;
			k++;
		}
	}

	public static <T> void insertionSort(ArrayList<T> arr, Comparator<? super T> cmp) {
		int stop = arr.size();
		int i;
		T key;
		int j;

		for (i = 1; i < stop; i++) {
			key = arr.get(i);
			j = i - 1;

			while (j >= 0 && cmp.compare(arr.get(j), key) > 0) {
				arr.set(j + 1, arr.get(j));
				j--;
			}
			arr.set(j + 1, key);
		}
	}

	// Quicksort

	public static <T> void quickSort(ArrayList<T> arr, Comparator<? super T> cmp) {

		// pick an item to be our pivot (via selecting its index) i.e. arr.get(mid)
		// Swap that with the last item

		quickSortHelper(arr, cmp, 0, arr.size() - 1);
	}

	public static <T> void quickSortHelper(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {
		if (rightBound <= leftBound) {
			return;
		}

		int index = partition(arr, cmp, leftBound, rightBound);

		// base case: leftbound > index-1 && rightBound < index
		quickSortHelper(arr, cmp, leftBound, index - 1);
		quickSortHelper(arr, cmp, index+1, rightBound);
	}

	public static <T> int partition(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {

		int pivot = halfPivot(leftBound, rightBound); 
	//	int pivot = randomMedianPivot(arr, cmp, leftBound, rightBound);
	//	int pivot = randomAvgPivot(leftBound, rightBound);

		swapReferences(arr, pivot, rightBound);
		
		int left = leftBound;
		int right = rightBound - 1;


		// while(left < right){
		while (left <= right) {
			while (left < rightBound && cmp.compare(arr.get(left), arr.get(rightBound)) <= 0) {
				left++;
			}
		
			while (right > leftBound && cmp.compare(arr.get(right), arr.get(rightBound)) >= 0) {
				right--;
			}

			if (left <= right) {
				swapReferences(arr, left, right);
				right--;
			}
		}
		swapReferences(arr, left, rightBound);
		
		return left;
	}
	
	//This one cuts the currently examined part of the array in half, picks that index
	public static int halfPivot(int leftBound, int rightBound) {
		return (leftBound+rightBound)/2;
	}
	
	//this one 
	public static <T> int randomMedianPivot(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {
		Random rand = new Random();
		
		
		int indexOne = rand.nextInt((rightBound-leftBound)+1)+leftBound;
		int indexTwo = rand.nextInt((rightBound-leftBound)+1)+leftBound;
		int indexThree = rand.nextInt((rightBound-leftBound)+1)+leftBound;

		if(cmp.compare(arr.get(indexOne), arr.get(indexTwo))<=0 && cmp.compare(arr.get(indexOne),arr.get(indexThree)) >= 0) {
			return indexOne;
		}
		else if(cmp.compare(arr.get(indexOne), arr.get(indexTwo))>=0 && cmp.compare(arr.get(indexOne),arr.get(indexThree)) <= 0) {
			return indexOne;
		}
		else if(cmp.compare(arr.get(indexTwo), arr.get(indexOne))<=0 && cmp.compare(arr.get(indexTwo),arr.get(indexThree)) >= 0) {
			return indexTwo;
		}
		else if(cmp.compare(arr.get(indexTwo), arr.get(indexOne))>=0 && cmp.compare(arr.get(indexTwo),arr.get(indexThree)) <= 0) {
			return indexTwo;
		}
		else if(cmp.compare(arr.get(indexThree), arr.get(indexOne))<=0 && cmp.compare(arr.get(indexThree),arr.get(indexTwo)) >= 0) {
			return indexThree;
		}
		else {
			return indexThree;
		}
	}
	
	public static <T> int randomAvgPivot(int leftBound, int rightBound) {
		Random rand = new Random();
		
		
		int indexOne = rand.nextInt((rightBound-leftBound)+1)+leftBound;
		int indexTwo = rand.nextInt((rightBound-leftBound)+1)+leftBound;
		int indexThree = rand.nextInt((rightBound-leftBound)+1)+leftBound;
		
		int result = (indexOne+indexTwo+indexThree)/3;
		return result;
	}

	public static <T> void swapReferences(ArrayList<T> arr, int left, int right) {
		T temp = arr.get(left);

		arr.set(left, arr.get(right));
		arr.set(right, temp);
	}

	
	
	public static ArrayList<Integer> generateBestCase(int size) {
		ArrayList<Integer> bestCase = new ArrayList<Integer>();
		for (int i = 1; i <= size; i++) {
			bestCase.add(i);
		}
		return bestCase;
	}

	public static ArrayList<Integer> generateAverageCase(int size) {
		ArrayList<Integer> avgCase = new ArrayList<Integer>();

		Random rand = new Random();

		for (int i = 1; i <= size; i++) {
			avgCase.add(i);
		}
		for (int j = 0; j < avgCase.size() - 1; j++) {
			swapReferences(avgCase, j, rand.nextInt(avgCase.size() - 1));
		}

		return avgCase;
	}

	public static ArrayList<Integer> generateWorseCase(int size) {
		ArrayList<Integer> worstCase = new ArrayList<Integer>();

		for (int i = size; i > 0; i--) {
			worstCase.add(i);
		}

		return worstCase;
	}
}

//public static <T> void partition(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {
//
//    int left = leftBound;
//    int right = rightBound - 1;
//    T pivot = arr.get(arr.size() - 1);
//
//    if (leftBound > rightBound)
//        return;
//    else {
//
//            while ((left < rightBound) && ((cmp.compare(arr.get(left), pivot) < 0))) {
//                left++;
//            }
//            while ((right > 0) && (cmp.compare(arr.get(right), pivot) > 0)) {
//                right--;
//            }
//
//        if (left > right) {
//            swapReferences(arr, left, right);
//        }
//        swapReferences(arr, left, rightBound);
//    }
//
//    partition(arr, cmp, leftBound, left - 1);
//    partition(arr, cmp, left + 1, right);
//}
