package assignment4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import org.junit.jupiter.api.Test;

public class AnagramTester {

	//Edge Case Ideas
	// - If a string has a number in it
	// - Run tests for sorting doubles and integers
	// - (Maybe?) creating a custom object
	
	private static Random rand;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// Set up the random number generator for the randomString function
		rand = new Random();
		rand.setSeed(0);
		
		// Reads a text file with a single word per line, returns them as an array of Strings
		String[] words = readFile("sample_word_list.txt");

	}
	
	@Test
	public void testSortSortedString() {
		String testWord = "Abracadabra";
		System.out.println(AnagramUtil.sort(testWord));
	}
	
	@Test
	public void insertionSortReadFileSort() {
		System.out.println("Testing Insertion Sort");
		StringComparator cmp = new StringComparator();
		String[] testWords = readFile("sample_word_list.txt");
		AnagramUtil.insertionSort(testWords, cmp);
		
		for(int i = 0; i < testWords.length; i++) {
			System.out.println(testWords[i]);
		}
		
		
	}
	
	@Test
	public void shellSortReadFileSort() {
		System.out.println("Testing Shell Sort");
		StringComparator cmp = new StringComparator();
		String[] testWords = readFile("sample_word_list.txt");
		AnagramUtil.shellSort(testWords, cmp);
		
		for(int i = 0; i < testWords.length; i++) {
			System.out.println(testWords[i]);
		}
	}


	
	//String comparator for testing
	public class StringComparator implements Comparator<String>{
		public int compare(String o1, String o2){
			return o1.compareTo(o2);
		}
	}
	
	
	
	
	// Create a random string [a-z] of specified length
	public static String randomString(int length)
	{
		String retval = "";
		for(int i = 0; i < length; i++)
		{
			// ASCII values a-z are contiguous (26 characters)
			retval += (char)('a' + (rand.nextInt(26)));
		}
		return retval;
	}
	
	// Reads words from a file (assumed to contain one word per line)
	// Returns the words as an array of strings.
	public static String[] readFile(String filename)
	{
		ArrayList<String> results = new ArrayList<String>();
		try
		{
			BufferedReader input = new BufferedReader(new FileReader(filename));
			while(input.ready())
			{
				results.add(input.readLine());
			}
			input.close();
		}
		catch(Exception e)
		{e.printStackTrace();}
		String[] retval = new String[1];
		return results.toArray(retval);
	}
	
}
