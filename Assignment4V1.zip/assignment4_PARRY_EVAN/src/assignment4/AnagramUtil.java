package assignment4;

import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class according to the specifications
 *
 */
public class AnagramUtil {

	// Go through this later and see if we can reuse

	// string.length refers to

	public static String sort(String input) {
		Character arr[] = new Character[input.length()];
		String output = "";
		input = input.toLowerCase();
		
		for (int i = 0; i < input.length(); i++) {
			
			arr[i] = input.charAt(i);
		}
		
		charCompare cmp = new charCompare();
		
		insertionSort(arr, cmp);

		for (int j = 0; j < input.length(); j++) {
			output += arr[j];
		}

		// Check if this toString actually works
		return output;
	}

	public static <T> void insertionSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;
		int i;
		T key;
		int j;

		for (i = 1; i < stop; i++) {
			key = arr[i]; // Initializes key to currently compared value
			j = i - 1; // sets J to the index directly before index i

			while (j >= 0 && (cmp.compare(arr[j], key) > 0)) {
				arr[j + 1] = arr[j];
				j--;
			}

			arr[j + 1] = key;
		}
	}
	
	public static <T> void shellSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;
		
		
		//draw this out visually to help better understand the underlying process
		
		for(int gap = (stop/2); gap>0; gap /= 2) {
			
			
			for (int i = gap; i < stop; i += 1) {
				
				T temp = arr[i];
				
				int j;
				for(j = i; j >= gap && cmp.compare(arr[j-gap], temp) > 0; j -= gap) {
					arr[j] = arr[j - gap];
				}
				
				arr[j] = temp;
				
			}
		}
		
	}
	
	static class charCompare implements Comparator<Character>{

		@Override
		public int compare(Character o1, Character o2) {
			return o1.compareTo(o2);
		}
		
	}

	public static boolean areAnagrams(String string1, String string2) {

		// Sort both strings (alphabetize their letters and use compareto?)
		// if sortedstring1.equals(sortedString2) return true
		// else return false

		return true;
	}

}
