package assignment2;
import java.util.GregorianCalendar;

public class LibraryBookGeneric<Type> extends Book {
	
	GregorianCalendar dueDate;
	Type holder;

	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		holder = null;
	}
	
	public Type getHolder() {
		return holder;
	}
	
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	public void setDueDate(int year, int month, int date) {
		dueDate = new GregorianCalendar(year, month, date);
	}

	public void setHolder(Type holder) {
		this.holder = holder;
	}
	
	public void checkIn() { //Make sure that this is actually setting values to null
		holder = null;
		dueDate = new GregorianCalendar(); 
	}
	
	public void checkOut(Type newHolder, int newYear, int newMonth, int newDate) {
		setHolder(newHolder);
		setDueDate(newYear, newMonth, newDate);
	}

	

	
}
