package assignment2;
import java.util.GregorianCalendar;

public class LibraryBook extends Book {
	
	GregorianCalendar dueDate;
	String holder;

	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		holder = null;
	}
	
	public String getHolder() {
		return holder;
	}
	
	
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	public void setDueDate(int year, int month, int date) {
		dueDate = new GregorianCalendar(year, month, date);
	}

	public void setHolder(String holder) {
		this.holder = holder;
	}
	
	public void checkIn() { 
		holder = null;
		dueDate = new GregorianCalendar(); 
	}
	
	public void checkOut(String newHolder, int newYear, int newMonth, int newDate) {
		setHolder(newHolder);
		setDueDate(newYear, newMonth, newDate);
	}

	

	
}
