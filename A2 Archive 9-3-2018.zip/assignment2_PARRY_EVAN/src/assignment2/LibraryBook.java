package assignment2;
import java.util.GregorianCalendar;

public class LibraryBook extends Book {
	
	GregorianCalendar dueDate = new GregorianCalendar();
	String holder;

	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		
		holder = null;
	}
	
	public String getHolder() {
		return holder;
	}

	
	//Perhaps we should try returning a new GregorianCalendar with the same values as dueDate
	//i.e. return new GregorianCalendar(dueDate YEAR, dueDate MONTH, dueDate DATE) etc.
	//This may require us to get the values as ints, then feed them into the new calendar to be returned.
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	public void setDueDate(int year, int month, int date) {
		dueDate.set(GregorianCalendar.YEAR, year);
		dueDate.set(GregorianCalendar.MONTH, month);
		dueDate.set(GregorianCalendar.DATE, date);
	}

	public void setHolder(String holder) {
		this.holder = holder;
	}

	

	
}
