package assignment6;

import java.util.NoSuchElementException;

public class MyLinkedList<T> implements List<T> {

	private Node head = null;
	private Node tail = null;
	private int size = 0;

	private class Node {

		T element;
		Node next;
		Node previous;

		Node(T data) {
			element = data;
			next = null;
			previous = null;
		}
	}

	public MyLinkedList() {

	}

	public Node getNode(int index) {
		Node curr = head;
		if (index < (size / 2)) {
			for (int i = 0; i < index; i++) {
				curr = curr.next;
			}
		} else {
			curr = tail;
			for (int j = size - 1; j > index; j++) {
				curr = curr.previous;
			}
		}
		return curr;
	}
	
	
	@Override
	public void addFirst(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size > 0) {
			newNode.next = head;
			head.previous = newNode;
		}

		else if (size == 0) {
			tail = newNode;
		}

		// Make sure that the new head's .previous is pointing to null
		head = newNode;

		size++;
	}

	@Override
	public void addLast(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size == 0) {
			addFirst(element);
		} else {
			newNode.previous = tail;
			tail.next = newNode;

			// Make sure that the new tail's .next is pointing to null

			tail = newNode;
			size++;
		}
	}

	@Override
	public void add(int index, T element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}

		if (index == 0) {
			addFirst(element);
		}
		if (index == size - 1) {
			addLast(element);
		}

		Node newNode = new Node(element);

		Node curr = getNode(index);
//		Node curr = head;
//
//		// This could be handled with a helper method I think.
//		if (index < (size / 2)) {
//			for (int i = 0; i < index; i++) {
//				curr = curr.next;
//			}
//		} else {
//			curr = tail;
//			for (int j = size - 1; j > index; j++) {
//				curr = curr.previous;
//			}
//		}

		newNode.previous = curr;
		newNode.next = curr.next;

		newNode.previous.next = newNode;
		newNode.next.previous = newNode;

		size++;
	}

	@Override
	public T getFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return head.element;
	}

	@Override
	public T getLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return tail.element;
	}

	@Override
	public T get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}

		Node curr = getNode(index);
		return curr.element;
//		if (index < (size / 2)) {
//			Node temp = head;
//
//			for (int i = 0; i < index; i++) {
//				temp = temp.next;
//			}
//			return temp.element;
//		} else {
//			Node temp = tail;
//
//			for (int j = size - 1; j > index; j++) {
//				temp = temp.previous;
//			}
//			return temp.element;
//		}

	}

	@Override
	public T removeFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T removeLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		Node removeNode = getNode(index);
	}

	@Override
	public int indexOf(T element) {
		// TODO Auto-generated method stub

		Node temp = head;
		for (int i = 0; i < size; i++) {
			if (temp.next.element.equals(element)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public int lastIndexOf(T element) {
		// TODO Auto-generated method stub
		Node temp = tail;
		for (int i = size - 1; i >= 0; i--) {
			if (temp.previous.element.equals(element)) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		head = null;
		tail = null;
		size = 0;
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		Object[] newArray = new Object[size];
		
		Node temp = head;
		for(int i = 0; i < size; i ++) {
			newArray[i] = temp.element;
			temp = temp.next;
		}
		
		return newArray;
	}

}
