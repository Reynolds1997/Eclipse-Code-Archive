package assignment4;

import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class according to the specifications
 *
 */
public class AnagramUtil {

	// Go through this later and see if we can reuse

	// string.length refers to

	public static String sort(String input) {
		Character arr[] = new Character[input.length()];
		String output = "";
		input = input.toLowerCase();

		for (int i = 0; i < input.length(); i++) {

			arr[i] = input.charAt(i);
		}

		charCompare cmp = new charCompare();

		insertionSort(arr, cmp);

		for (int j = 0; j < input.length(); j++) {
			output += arr[j];
		}

		// Check if this toString actually works
		return output;
	}

	public static <T> void insertionSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;
		int i;
		T key;
		int j;

		for (i = 1; i < stop; i++) {
			key = arr[i]; // Initializes key to currently compared value
			j = i - 1; // sets J to the index directly before index i

			while (j >= 0 && (cmp.compare(arr[j], key) > 0)) {
				arr[j + 1] = arr[j];
				j--;
			}

			arr[j + 1] = key;
		}
	}

	public static <T> void shellSort(T[] arr, Comparator<? super T> cmp) {
		int stop = arr.length;

		// draw this out visually to help better understand the underlying process

		for (int gap = (stop / 2); gap > 0; gap /= 2) {

			for (int i = gap; i < stop; i += 1) {

				T temp = arr[i];

				int j;
				for (j = i; j >= gap && cmp.compare(arr[j - gap], temp) > 0; j -= gap) {
					arr[j] = arr[j - gap];
				}

				arr[j] = temp;

			}
		}

	}

	public static boolean areAnagrams(String string1, String string2) {

		String inString1 = sort(string1);
		String inString2 = sort(string2);

		if (inString1.equals(inString2)) {
			return true;
		}
		return false;
	}

	public static String[] getLargestAnagramGroup(String[] array) {

		String[] arr = new String[array.length];
		
		for (int m = 0; m < array.length; m++) {
			arr[m] = array[m];
		}

		for (int i = 0; i < arr.length; i++) {
			arr[i] = sort(arr[i]);
		}

		stringCompare cmp = new stringCompare();

		shellSort(arr, cmp);

		int largestCounter = 1;
		int currentCounter = 1;

		String largestAnagram = "";

		for (int j = 0; j < arr.length - 1; j++) {

			if (areAnagrams(arr[j], arr[j + 1]) == true) {
				//System.out.println(arr[j]);
				currentCounter++;
			} else { // if they aren't anagrams
				if (currentCounter > largestCounter) {
					largestCounter = currentCounter;
					largestAnagram = arr[j];
					currentCounter = 1;
					//System.out.println("Largest anagram " + largestAnagram);
				} else {
					currentCounter = 1;
				}
			}
		}

		String[] output = new String[largestCounter];
		int counter = 0;
		
		for(int k = 0; k < array.length; k++) {
			String testWord = array[k];
			if(areAnagrams(testWord, largestAnagram)) {
				//System.out.println(testWord);
				output[counter] = array[k];
				counter++;
			}
		}
		
//		for (int k = 0; k < array.length; k++) {
//			for (int l = 0; l < output.length; l++) {
//				String testWord = array[k];
//				System.out.println("Testword: " +testWord);
//				if (areAnagrams(testWord, largestAnagram)) {
//					output[l] = array[k];
//				}
//			}
//		}

		return output;
	}

	static class charCompare implements Comparator<Character> {

		@Override
		public int compare(Character o1, Character o2) {
			return o1.compareTo(o2);
		}

	}

	static class stringCompare implements Comparator<String> {

		@Override
		public int compare(String o1, String o2) {
			if (o1.compareTo(o2) < 0) {
				return -1;
			} else if (o1.compareTo(o2) > 0) {
				return 1;
			}
			return 0;
		}
	}
}
