package assignment8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class BinarySearchTreeTimingTest2 {

	public static void main(String[] args) {

		long midPointTime;
		long midPointTime2;

		long startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000) {

		}

		long stopTime = 0;
		long stopTime2 = 0;
		long startTime2 = 0;

		long javaStart = 0;
		long treeStart = 0;
		long javaStop = 0;
		long treeStop = 0;

		int timesToLoop = 2500;

		for (int N = 100; N <= 10000; N += 100) {
			BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>();
			TreeSet<Integer> javaTree = new TreeSet<Integer>();

			ArrayList<Integer> random = new ArrayList<Integer>();

			for (int i = 0; i < N; i++) {
				random.add(i);
			}

			Collections.shuffle(random);

			javaStart = System.nanoTime();
			javaTree.addAll(random);
			javaStop = System.nanoTime();

			startTime = System.nanoTime();

			for (int j = 0; j <= timesToLoop; j++) {
				for (int k = 0; k < N;k++) {
					javaTree.contains(k);
				}

			}

			midPointTime = System.nanoTime();

			for (long l = 0; l <= timesToLoop; l++) {
				for (int k = 0; k < N;k++) {
				
				}
			}

			stopTime = System.nanoTime();

			treeStart = System.nanoTime();
			tree.addAll(random);
			treeStop = System.nanoTime();

			startTime2 = System.nanoTime();

			for (int j = 0; j <= timesToLoop; j++) {

				for (int k = 0; k < N;k++) {
					tree.contains(k);
				}
			}

			midPointTime2 = System.nanoTime();

			for (long l = 0; l <= timesToLoop; l++) {
				for (int k = 0; k < N;k++) {
					
				}

			}

			stopTime2 = System.nanoTime();
			// part 2 end

			double averageTime = (double) ((midPointTime - startTime) - (stopTime - midPointTime)) / timesToLoop;

			double javaAddTime = (double) (javaStop - javaStart);

			// our tree
			double averageTime2 = (double) ((midPointTime2 - startTime2) - (stopTime2 - midPointTime2)) / timesToLoop;

			double treeAddTime = (double) (treeStop - treeStart);

			// System.out.println(N + "\t" + javaAddTime/N);
			//System.out.println(N + "\t" + treeAddTime/N);

			 //System.out.println(N + "\t" + averageTime/N);
			 System.out.println(N + "\t" + averageTime2/N);

		}

	}

}
