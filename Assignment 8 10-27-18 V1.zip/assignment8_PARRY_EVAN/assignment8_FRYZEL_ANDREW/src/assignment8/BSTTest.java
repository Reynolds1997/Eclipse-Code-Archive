package assignment8;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class BSTTest {

	@Test
	public void testWrite() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");

		test.writeDot("testWriteString");
	}

	@Test
	public void testWriteInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);
		test.add(5);
		test.add(632);

		test.writeDot("TestWriteInteger");
	}

	@Test
	public void testAddAll() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");

		BinarySearchTree<String> test2 = new BinarySearchTree<String>();
//		test2.add("Grace");
//		test2.add("Alice");
//		test2.add("Charlie");
//		test2.add("Agatha");
//		test2.add("Zachary");
//		test2.add("Alice");
//		test2.add("Jennifer");
//		test2.add("Zachary");
//		test2.add("Alice");

		test2.addAll(testArray);

		for (int i = 0; i < test.size(); i++) {
			assertTrue(test.contains(testArray.get(i)));
		}

		System.out.println(test2.size());
		test.writeDot("Test Add All");
	}

	@Test
	public void testAddAllFalse() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

	
		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");

		 assertFalse(test.add("Grace"));
	

		test.writeDot("Test Add All");
	}

	@Test
	public void testAddAllInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		ArrayList<Integer> testArray = new ArrayList<Integer>();

		testArray.add(52);
		testArray.add(25);
		testArray.add(72);
		testArray.add(32);
		testArray.add(5);
		testArray.add(632);

		test.addAll(testArray);

		assertTrue(test.containsAll(testArray));

		test.writeDot("Test Add All Integer");
	}

	@Test
	public void testRemoveWithDuplicates() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");
		test.add("Jennifer");

		test.remove("Alice");
		test.remove("Jennifer");

		assertEquals(4, test.size());

		test.writeDot("Test Remove Duplicates");
	}

	@Test
	public void testRemove() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Jennifer");

		test.remove("Alice");
		test.remove("Jennifer");

		assertEquals(4, test.size());

		test.writeDot("Test Remove");
	}

	// TODO
	// Doesn't work
	@Test
	public void testRemoveAllWithExtraInList() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Jennifer");

		ArrayList<String> testArray = test.toArrayList();
		testArray.add("Jennifer");

		test.removeAll(testArray);
		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

		test.writeDot("Test Remove With Duplicates");
	}

	@Test
	public void testRemoveAllExactSameValues() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Jennifer");

		ArrayList<String> testArray = test.toArrayList();

		test.removeAll(testArray);
		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

		test.writeDot("Test Remove All Exact Same Values Both");
	}

	@Test
	public void testRemoveWithDuplicatesInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);
		test.add(5);
		test.add(632);

		test.remove(5);
		test.remove(32);

		assertEquals(4, test.size());

		test.writeDot("Test Integer Remove With Duplicates");
	}

	@Test
	public void testRemoveInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		test.remove(5);
		test.remove(32);

		assertEquals(4, test.size());

		test.writeDot("Test Remove Integer");
	}

	// TODO
	// Doesn't work
	@Test
	public void testRemoveAllWithExtraInListInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		ArrayList<Integer> testArray = test.toArrayList();
		test.add(632);

		test.removeAll(testArray);
		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

		test.writeDot("Test Integer Remove All With Extra");
	}

	@Test
	public void testRemoveAllWithExactSameValuesInArrayListInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		ArrayList<Integer> testArray = test.toArrayList();

		test.removeAll(testArray);
		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

		test.writeDot("Test Integer Remove All Same Values In Both");
	}

	@Test
	public void testClear() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");

		test.clear();

		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

		test.writeDot("Test Clear");
	}

	@Test
	public void testClearInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(502);
		test.add(125);
		test.add(72);
		test.add(322);
		test.add(15);
		test.add(632);
		test.add(215);
		test.add(1632);

		test.clear();

		assertEquals(0, test.size());
		assertTrue(test.isEmpty());
		test.writeDot("Test Clear Integer");

	}

	@Test
	public void testClearAlreadyEmpty() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.clear();

		assertEquals(0, test.size());
		assertTrue(test.isEmpty());

	}

	@Test
	public void testContainsTrue() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		assertTrue(test.contains("Agatha"));
		test.writeDot("Test Contains True");

	}

	@Test
	public void testContainsFalse() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");

		assertFalse(test.contains("Christie"));
		test.writeDot("Test Contains False");

	}

	@Test
	public void testContainsTrueInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);
		assertTrue(test.contains(5));
		test.writeDot("Test Contains True Integer");

	}

	@Test
	public void testContainsFalseInteger() {
		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		assertFalse(test.contains(123));
		assertFalse(test.contains(23));
		test.writeDot("Test Contains False Integer");

	}

	@Test
	public void testContainsAllTrue() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");
		testArray.add("Alice");
		testArray.add("Jennifer");

		assertTrue(test.containsAll(testArray));
		test.writeDot("Test Contains All True");

	}

	@Test
	public void testContainsAllFalse() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");
		testArray.add("Alice");
		testArray.add("Jennifer");

		assertFalse(test.containsAll(testArray));
		test.writeDot("Test Contains All False");

	}

	@Test
	public void testContainsAllTrueInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		ArrayList<Integer> testArray = new ArrayList<Integer>();
		testArray.add(52);
		testArray.add(25);
		testArray.add(72);
		testArray.add(32);
		testArray.add(5);
		testArray.add(632);

		assertTrue(test.containsAll(testArray));
		test.writeDot("Test Contains Al True Integer");

	}

	@Test
	public void testContainsAllFalseInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(52);
		test.add(25);
		test.add(72);
		test.add(32);
		test.add(5);
		test.add(632);

		ArrayList<Integer> testArray = new ArrayList<Integer>();
		testArray.add(52);
		testArray.add(25);
		testArray.add(72);
		testArray.add(32);
		testArray.add(5);
		testArray.add(632);
		testArray.add(505);
		testArray.add(1632);

		assertFalse(test.containsAll(testArray));
		test.writeDot("Test Contains Al False Integer");

	}

	// TODO
	@Test
	public void testLeftMost() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();
		test.add("Jennifer");
		test.add("Monique");
		test.add("Paul");
		test.add("Noah");
		test.add("Grace");
		test.add("Brent");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Opera");
		test.add("Aggie");

		assertEquals("Agatha", test.first());
		test.writeDot("Test Left Most");

	}

	@Test
	public void testRightMost() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();
		test.add("Jennifer");
		test.add("Monique");
		test.add("Paul");
		test.add("Noah");
		test.add("Grace");
		test.add("Brent");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Opera");
		test.add("Aggie");

		assertEquals("Zachary", test.last());
		test.writeDot("Test Right Most");

	}

	@Test
	public void testToArray() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Jennifer");
		test.add("Monique");
		test.add("Paul");
		test.add("Noah");
		test.add("Grace");
		test.add("Brent");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Opera");
		test.add("Aggie");

		ArrayList<String> testArray = test.toArrayList();

		assertTrue(test.containsAll(testArray));
		assertEquals(12, test.size());
		assertEquals(12, testArray.size());
		test.writeDot("Test To Array");

	}

	@Test
	public void testToArrayInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		test.add(502);
		test.add(125);
		test.add(72);
		test.add(322);
		test.add(15);
		test.add(632);
		test.add(215);
		test.add(1632);

		ArrayList<Integer> testArray = test.toArrayList();

		assertTrue(test.containsAll(testArray));
		assertEquals(8, test.size());
		assertEquals(8, testArray.size());
		test.writeDot("Test To Array Integer");

	}
}
