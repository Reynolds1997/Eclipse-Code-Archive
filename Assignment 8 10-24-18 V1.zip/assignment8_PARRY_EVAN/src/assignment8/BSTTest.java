package assignment8;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class BSTTest {

	@Test
	public void testWrite() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");

		test.writeDot("10-23-2018 Test01");
	}

	@Test
	public void testAddAll() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");
		testArray.add("Alice");
		testArray.add("Jennifer");
		testArray.add("Zachary");
		testArray.add("Alice");

		BinarySearchTree<String> test2 = new BinarySearchTree<String>();
		test2.add("Grace");
		test2.add("Alice");
		test2.add("Charlie");
		test2.add("Agatha");
		test2.add("Zachary");
		test2.add("Alice");
		test2.add("Jennifer");
		test2.add("Zachary");
		test2.add("Alice");

		test.addAll(testArray);

		for (int i = 0; i < test.size(); i++) {
			assertTrue(test.contains(testArray.get(i)));
		}

		test.writeDot("Add All Test");
	}

	@Test
	public void testAddAllInteger() {

		BinarySearchTree<Integer> test = new BinarySearchTree<Integer>();

		ArrayList<Integer> testArray = new ArrayList<Integer>();

		testArray.add(52);
		testArray.add(25);
		testArray.add(72);
		testArray.add(32);
		testArray.add(5);
		testArray.add(632);

		test.addAll(testArray);

		for (int i = 0; i < test.size() - 1; i++) {
			assertTrue(test.contains(testArray.get(i)));
		}

		test.writeDot("Add All Test Integer");
	}

	@Test
	public void testRemove() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");
		test.add("Jennifer");

//		test.remove("Alice");
//		test.remove("Jennifer");

		assertEquals(6, test.size());

		test.writeDot("10-23-2018 Test02");
	}

	// TODO
	// Doesn't work
	@Test
	public void testRemoveAll() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Jennifer");

		ArrayList<String> testArray = test.toArrayList();
		testArray.add("Jennifer");

		test.removeAll(testArray);
		System.out.println("after removign the size is " + test.size());

		test.writeDot("Remove All Test size");
	}

	@Test
	public void testClear() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");

		System.out.println("Is empty: " + test.isEmpty());
		test.clear();
		System.out.println("Is empty: " + test.isEmpty());
	}

	@Test
	public void testContains() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");

		System.out.println("Contains Agatha: " + test.contains("Agatha"));
		System.out.println("Contains Christie: " + test.contains("Christie"));
	}

	@Test
	public void testContainsAllTrue() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Jennifer");

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");
		testArray.add("Alice");
		testArray.add("Jennifer");

		System.out.println("Contains All True" + test.containsAll(testArray));

	}

	@Test
	public void testContainsAllFalse() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Grace");
		test.add("Alice");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");

		ArrayList<String> testArray = new ArrayList<String>();
		testArray.add("Grace");
		testArray.add("Alice");
		testArray.add("Charlie");
		testArray.add("Agatha");
		testArray.add("Zachary");
		testArray.add("Alice");
		testArray.add("Jennifer");

		System.out.println("Contains All False " + test.containsAll(testArray));

	}

	@Test
	public void testLeftRight() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();
		test.add("Jennifer");
		test.add("Monique");
		test.add("Paul");
		test.add("Noah");
		test.add("Grace");
		test.add("Brent");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Opera");
		test.add("Aggie");

		test.writeDot("Left Right");

		System.out.println("First is: " + test.first());
		System.out.println("Last is: " + test.last());
	}

	@Test
	public void testToArray() {

		BinarySearchTree<String> test = new BinarySearchTree<String>();

		test.add("Jennifer");
		test.add("Monique");
		test.add("Paul");
		test.add("Noah");
		test.add("Grace");
		test.add("Brent");
		test.add("Charlie");
		test.add("Agatha");
		test.add("Zachary");
		test.add("Alice");
		test.add("Opera");
		test.add("Aggie");

		ArrayList<String> testArray = test.toArrayList();
		System.out.println("Test Array: " + testArray.toString());
	}
}
