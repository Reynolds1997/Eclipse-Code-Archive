/**@author Evan Parry & Andrew Fryzel; starter code by Daniel Kopta  
* Assignment 2: LibraryTest
* CS2420-001
*/

package assignment2;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Testing class for Library.
 * 
 * 
 */
public class LibraryTest {

	public static void main(String[] args) {
		// test an empty library
		Library lib = new Library();

		if (lib.lookup(978037429279L) != null)
			System.err.println("TEST FAILED -- empty library: lookup(isbn)");
		ArrayList<LibraryBook> booksCheckedOut = lib.lookup("Jane Doe");
		if (booksCheckedOut == null || booksCheckedOut.size() != 0)
			System.err.println("TEST FAILED -- empty library: lookup(holder)");
		if (lib.checkout(978037429279L, "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- empty library: checkout");
		if (lib.checkin(978037429279L))
			System.err.println("TEST FAILED -- empty library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- empty library: checkin(holder)");

		// test a small library
		lib.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib.add(9780446580342L, "David Baldacci", "Simple Genius");

		if (lib.lookup(9780330351690L) != null)
			System.err.println("TEST FAILED -- small library: lookup(isbn)");
		if (!lib.checkout(9780330351690L, "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- small library: checkout");
		booksCheckedOut = lib.lookup("Jane Doe");
		if (booksCheckedOut == null || booksCheckedOut.size() != 1
				|| !booksCheckedOut.get(0).equals(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut.get(0).getHolder().equals("Jane Doe")
				|| !booksCheckedOut.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED -- small library: lookup(holder)");

		if (!lib.checkin(9780330351690L))
			System.err.println("TEST FAILED -- small library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- small library: checkin(holder)");

		// test a medium library
		lib.addAll("Mushroom_Publishing.txt");

		// All tests below this comment were added by Fryzel and Parry
		// for the purpose of additional testing.

		// Test lookup for unknown holder
		if (lib.lookup(9781843192022L) == null) {
			System.out.println("No holder found for this ISBN");
		}

		// Test lookup for unknown ISBN
		if (lib.lookup(8781843192022L) == null) {
			System.out.println("No book found with this ISBN");
		}

		// Test to make sure books can be properly checked out
		if (lib.checkout(9781843192022L, "Bob Human", 2, 2, 2009) == true) {
			System.out.println("Book successfully checked out.");
		}

		// Test to see if a checked out book can be checked out again
		if (lib.checkout(9781843192022L, "Alice Person", 3, 3, 2010) == true) {
			System.err.println("TEST FAILED - Medium library: checkout. Cannot check out an already checked out book.");

		}

		// Test that the book was checked out to Bob Human
		if (lib.lookup(9781843192022L) == "Bob Human") {
			System.out.println("Bob Human has checked out this book.");
		}
		if (lib.lookup(9781843192022L) != "Bob Human") {
			System.err.println("TEST FAILED - Medium library: checkout. Book checked out to wrong person.");
		}

		// Print out all books checked out to indicated person
		System.out.println("Alice Person has checked out: " + lib.lookup("Alice Person"));
		System.out.println("Bob Human has checked out: " + lib.lookup("Bob Human"));

		// Test that lower case and upper case holders aren't identified as the same
		// holder
		// Lowercase "bob human" tested
		System.out.println("bob human has checked out: " + lib.lookup("bob human"));

		// Check out more books to "Bob Human"
		lib.checkout(9781843190363L, "Bob Human", 2, 3, 2009);
		lib.checkout(9781843193319L, "Bob Human", 3, 1, 1999);
		lib.checkout(9781843190349L, "Bob Human", 4, 23, 2019);

		// Test that the books were checked out correctly
		if (lib.lookup(9781843190363L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}
		if (lib.lookup(9781843193319L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}
		if (lib.lookup(9781843190349L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}

		// Test that the books checked out can be checked in properly
		// Prints out the list of books checked out to "Bob Human",
		// checks in a book,
		// prints out the list again,
		// check in all books,
		// prints out the list of checked out books one last time
		System.out.println("Bob Human has checked out: " + lib.lookup("Bob Human"));
		lib.checkin(9781843193319L);
		System.out.println("Bob Human has checked out: " + lib.lookup("Bob Human"));
		lib.checkin("Bob Human");
		System.out.println("Bob Human has checked out: " + lib.lookup("Bob Human"));

		// Test that all the books are checked in and that the ArrayList is empty
		ArrayList<LibraryBook> bob = new ArrayList<LibraryBook>();
		bob = lib.lookup("Bob Human");
		if (bob.size() != 0)
			System.err.println("TEST FAILED - All books not successfully checked in");

		// Test the dates to see if there is a limit.
		// Why can the dates be set to bad dates??
		lib.checkout(9781843190363L, "Alice Person", 5, 12, 2012);
		System.out.println("Alice Person has checked out: " + lib.lookup("Alice Person"));

		lib.checkout(9781843191230L, "Alice Person", 33, 14, 20124);
		System.out.println("Alice Person has checked out: " + lib.lookup("Alice Person"));

		System.out.println("Testing done.");
	}

	/**
	 * Returns a library of "dummy" books (random ISBN and placeholders for author
	 * and title).
	 * 
	 * Useful for collecting running times for operations on libraries of varying
	 * size.
	 * 
	 * @param size -- size of the library to be generated
	 * 
	 * @return
	 */
	public static ArrayList<LibraryBook> generateLibrary(int size) {
		ArrayList<LibraryBook> result = new ArrayList<LibraryBook>();

		for (int i = 0; i < size; i++) {
			// generate random ISBN
			Random randomNumGen = new Random();
			String isbn = "";
			for (int j = 0; j < 13; j++)
				isbn += randomNumGen.nextInt(10);

			result.add(new LibraryBook(Long.parseLong(isbn), "An author", "A title"));
		}

		return result;
	}

	/**
	 * Returns a randomly-generated ISBN (a long with 13 digits).
	 * 
	 * Useful for collecting running times for operations on libraries of varying
	 * size.
	 */
	public static long generateIsbn() {
		Random randomNumGen = new Random();

		String isbn = "";
		for (int j = 0; j < 13; j++)
			isbn += randomNumGen.nextInt(10);

		return Long.parseLong(isbn);
	}
}
