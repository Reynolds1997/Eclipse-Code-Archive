/**@author Evan Parry & Andrew Fryzel; starter code by Daniel Kopta  
 * Assignment 2: LibraryBook
 * CS2420-001
 */

package assignment2;

import java.util.GregorianCalendar;

public class LibraryBook extends Book {

	GregorianCalendar dueDate;
	String holder;

	/**
	 * LibraryBook constructor. Uses specified isbn, author, and title and sets
	 * GregorianCalendar and holder to null.
	 * 
	 * @param _isbn   -- the book's ISBN
	 * @param _author -- the book's author
	 * @param _title  -- the book's title
	 */
	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		holder = null;
	}

	/**
	 * @return the book's holder
	 */
	public String getHolder() {
		return holder;
	}

	/**
	 * @return the book's due date (represented by a GregorianCalendar)
	 */
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	/**
	 * Sets the book's due date using the specified date information (year, month,
	 * date).
	 * 
	 * @param year  -- the due date year
	 * @param month -- the due date month
	 * @param date  -- the due date day
	 */
	public void setDueDate(int year, int month, int date) {
		dueDate = new GregorianCalendar(year, month, date);
	}

	/**
	 * @param holder -- the book's new holder
	 */
	public void setHolder(String holder) {
		this.holder = holder;
	}

	/**
	 * Sets a book's holder and dueDate to null as part of a checkin process.
	 */
	public void checkIn() {
		holder = null;
		dueDate = new GregorianCalendar();
	}

	/**
	 * Checks out a book to a new holder and sets the book's new due date.
	 * 
	 * @param newHolder -- the book's new holder
	 * @param newYear -- the year of the book's new due date
	 * @param newMonth -- the month of the book's new due date
	 * @param newDate -- the day of the book's new due date
	 */
	public void checkOut(String newHolder, int newYear, int newMonth, int newDate) {
		setHolder(newHolder);
		setDueDate(newYear, newMonth, newDate);
	}

}
