/**@author Evan Parry & Andrew Fryzel; starter code by Daniel Kopta  
 * Assignment 2: LibraryGenericTest
 * CS2420-001
 */

package assignment2;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/**
 * Testing class for LibraryGeneric.
 *
 */
public class LibraryGenericTest {

	public static void main(String[] args) {

		// test a library that uses names (String) to id patrons
		LibraryGeneric<String> lib1 = new LibraryGeneric<String>();
		lib1.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib1.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib1.add(9780446580342L, "David Baldacci", "Simple Genius");

		String patron1 = "Jane Doe";

		if (!lib1.checkout(9780330351690L, patron1, 1, 1, 2008))
			System.err.println("TEST FAILED: first checkout");
		if (!lib1.checkout(9780374292799L, patron1, 1, 1, 2008))
			System.err.println("TEST FAILED: second checkout");
		ArrayList<LibraryBookGeneric<String>> booksCheckedOut1 = lib1.lookup(patron1);
		if (booksCheckedOut1 == null || booksCheckedOut1.size() != 2
				|| !booksCheckedOut1.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut1.contains(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"))
				|| !booksCheckedOut1.get(0).getHolder().equals(patron1)
				|| !booksCheckedOut1.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1))
				|| !booksCheckedOut1.get(1).getHolder().equals(patron1)
				|| !booksCheckedOut1.get(1).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED: lookup(holder)");
		if (!lib1.checkin(patron1))
			System.err.println("TEST FAILED: checkin(holder)");

		// test a library that uses phone numbers (PhoneNumber) to id patrons
		LibraryGeneric<PhoneNumber> lib2 = new LibraryGeneric<PhoneNumber>();
		lib2.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib2.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib2.add(9780446580342L, "David Baldacci", "Simple Genius");

		PhoneNumber patron2 = new PhoneNumber("801.555.1234");

		if (!lib2.checkout(9780330351690L, patron2, 1, 1, 2008))
			System.err.println("TEST FAILED: first checkout");
		if (!lib2.checkout(9780374292799L, patron2, 1, 1, 2008))
			System.err.println("TEST FAILED: second checkout");
		ArrayList<LibraryBookGeneric<PhoneNumber>> booksCheckedOut2 = lib2.lookup(patron2);
		if (booksCheckedOut2 == null || booksCheckedOut2.size() != 2
				|| !booksCheckedOut2.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut2.contains(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"))
				|| !booksCheckedOut2.get(0).getHolder().equals(patron2)
				|| !booksCheckedOut2.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1))
				|| !booksCheckedOut2.get(1).getHolder().equals(patron2)
				|| !booksCheckedOut2.get(1).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED: lookup(holder)");
		if (!lib2.checkin(patron2))
			System.err.println("TEST FAILED: checkin(holder)");

		// All tests below this comment were added by Fryzel and Parry
		// for the purpose of additional testing.

		// Tests with a medium library
		LibraryGeneric<String> lib3 = new LibraryGeneric<String>();
		lib3.addAll("Mushroom_Publishing.txt");

		String patron3 = "Bob Person";

		lib3.checkout(9781843190479L, patron3, 3, 3, 2018);
		lib3.checkout(9781843190004L, patron3, 1, 1, 2018);
		lib3.checkout(9781843190363L, patron3, 2, 2, 2018);

		// Test the overdue list of dates after the specified date. Dates that are equal
		// are not considered over due
		lib3.getOverdueList(4, 4, 2018);

		// Orders the books alphabetically by author

		lib3.getOrderedByAuthor();

		// Library 4 tests for a Phone Number Holder

		// Create a new Phone Number Generic Library and add the books to it
		LibraryGeneric<PhoneNumber> lib4 = new LibraryGeneric<PhoneNumber>();
		lib4.addAll("Mushroom_Publishing.txt");

		PhoneNumber patron4 = new PhoneNumber("801.876.5309");

		// Test that the books are checked out by Phone Number
		System.out.println("Phone Number tests:\n");
		if (lib4.checkout(9781843190936L, patron4, 4, 4, 2019) != true) {
			System.err.println("TEST FAILED: Book check out not successful");
		} else
			System.out.println("Patron 4 has checked out the books " + lib4.lookup(patron4));

		if (lib4.checkout(9781843190479L, patron4, 5, 7, 2020) != true) {
			System.err.println("TEST FAILED: Book check out not successful");
		} else
			System.out.println("Patron 4 has checked out the books " + lib4.lookup(patron4));
		if (lib4.checkout(9781843190677L, patron4, 6, 10, 2015) != true) {
			System.err.println("TEST FAILED: Book check out not successful");
		} else
			System.out.println("Patron 4 has checked out the books " + lib4.lookup(patron4) + "\n");

		// Test that the overdue books for patron 4 are correct
		System.out.println("Overdue books: " + lib4.getOverdueList(4, 4, 2019));
		// Print the author sort
		System.out.println("\nAuthor sort: " + lib4.getOrderedByAuthor() + "\n");

		// lib4.checkout(9781843190400L, "Bob Human", 12, 21, 2012);

		// Test that the book can be checked in by ISBN
		// First prints out list of checked out books
		System.out.println("Current checked out books are " + lib4.lookup(patron4));
		if (lib4.checkin(9781843190936L) != true) {
			System.err.println("TEST FAILED: book not checked in.");
		} else
			System.out.println("Checked in book. Current checked out books are " + lib4.lookup(patron4));

		// Test that the book can be checked in by Phone Number.
		// Checks in all books of the holder
		if (lib4.checkin(patron4) != true) {
			System.err.println("TEST FAILED: book not checked in.");
		} else
			System.out.println("Checked in book. Current checked out books are " + lib4.lookup(patron4) + "\n");

		
		
		
		
		
		// Test all the same tests from the normal Library to ensure they still work
		// with the Generic Library
		System.out.println("\nNormal Holder tests:\n");
		LibraryGeneric<String> lib5 = new LibraryGeneric<String>();
		lib5.addAll("Mushroom_Publishing.txt");

		// Test lookup for unknown holder
		if (lib5.lookup(9781843192022L) == null) {
			System.out.println("No holder found for this ISBN");
		}

		// Test lookup for unknown ISBN
		if (lib5.lookup(8781843192022L) == null) {
			System.out.println("No book found with this ISBN");
		}

		// Test to make sure books can be properly checked out
		if (lib5.checkout(9781843192022L, "Bob Human", 2, 2, 2009) == true) {
			System.out.println("Book successfully checked out.");
		}

		// Test to see if a checked out book can be checked out again
		if (lib5.checkout(9781843192022L, "Alice Person", 3, 3, 2010) == true) {
			System.err.println("TEST FAILED - Medium library: checkout. Cannot check out an already checked out book.");

		}

		// Test that the book was checked out to Bob Human
		if (lib5.lookup(9781843192022L) == "Bob Human") {
			System.out.println("Bob Human has checked out this book.");
		}
		if (lib5.lookup(9781843192022L) != "Bob Human") {
			System.err.println("TEST FAILED - Medium library: checkout. Book checked out to wrong person.");
		}

		// Print out all books checked out to indicated person
		System.out.println("\nAlice Person has checked out: " + lib5.lookup("Alice Person"));
		System.out.println("\nBob Human has checked out: " + lib5.lookup("Bob Human"));

		// Test that lower case and upper case holders aren't identified as the same
		// holder
		// Lowercase "bob human" tested
		ArrayList<LibraryBookGeneric<String>> lilBob = new ArrayList<LibraryBookGeneric<String>>();
		lilBob = lib5.lookup("bob human");
		if (lilBob.size() != 0)
			System.err.println("TEST FAILED: Failed test for same name, different capitalization.");
		else
			System.out.println("Lowercase \"bob human\" has checked out: " + lib5.lookup("bob human"));

		// Check out more books to "Bob Human"
		lib5.checkout(9781843190363L, "Bob Human", 2, 3, 2009);
		lib5.checkout(9781843193319L, "Bob Human", 3, 1, 1999);
		lib5.checkout(9781843190349L, "Bob Human", 4, 23, 2019);

		// Test that the books were checked out correctly
		if (lib5.lookup(9781843190363L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}
		if (lib5.lookup(9781843193319L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}
		if (lib5.lookup(9781843190349L) != "Bob Human") {
			System.err.println("TEST FAILED - Book checked out to wrong person.");
		}

		// Test that the books checked out can be checked in properly
		// Prints out the list of books checked out to "Bob Human",
		// checks in a book,
		// prints out the list again,
		// check in all books,
		// prints out the list of checked out books one last time
		System.out.println("Bob Human has checked out: " + lib5.lookup("Bob Human"));
		lib5.checkin(9781843193319L);
		System.out.println("Bob Human has checked out: " + lib5.lookup("Bob Human"));
		lib5.checkin("Bob Human");
		System.out.println("Bob Human has checked out: " + lib5.lookup("Bob Human"));

		// Test that all the books are checked in and that the ArrayList is empty

		ArrayList<LibraryBookGeneric<String>> bob = new ArrayList<LibraryBookGeneric<String>>();
		bob = lib5.lookup("Bob Human");
		if (bob.size() != 0)
			System.err.println("TEST FAILED - All books not successfully checked in");
		else
			System.out.println("The books are all checked in for Bob Human\n");

		// Test the dates to see if there is a limit.
		// Why can the dates be set to bad dates??
		lib5.checkout(9781843190363L, "Alice Person", 5, 12, 2012);
		System.out.println("Alice Person has checked out: " + lib5.lookup("Alice Person"));

		lib5.checkout(9781843191230L, "Alice Person", 33, 14, 20124);
		System.out.println("Alice Person has checked out: " + lib5.lookup("Alice Person"));

		
		System.out.println("\nTesting done.");
		
		// Untestable Tests that we thought of but couldn't test
		// Library 6 tests
		// Cant create one Library Generic Array List to check in both String and Phone
		// Number types
		// LibraryGeneric<Type> lib6 = new LibraryGeneric<Type>();

		// Library 7 test
		// Just tested to see how a library could be made to allow both types
		//LibraryGeneric<Object> lib7 = new LibraryGeneric<Object>();

		//lib7.lookup(patron4);
		//lib7.lookup(patron3);

	

	}
}
