package assignment6;

import java.util.ArrayList;
import java.util.LinkedList;

public class TimeMyLinkedList {

	public static void main(String[] args) {
		
		
		long startTime, midPointTime, stopTime;
		
		startTime = System.nanoTime();
		
		while ((System.nanoTime() - startTime) < 1000000000) {
		}
		
		int timesToLoop = 50;
		int index = (1);
		
		for(int N = 100; N <= 10000; N+= 100) {
			
			//Change this for different test
			ArrayList<String> testList = new ArrayList<String>();
			for(int k = 0; k <= N; k+= 1) {
				String input = Integer.toString(k);
				testList.add(input);
			}
			
//			MyLinkedList<String> testList = new MyLinkedList<String>();
//			for(int k = 0; k <= N; k+= 1) {
//				String input = Integer.toString(k);
//				testList.addLast(input);
//			}
			
//			LinkedList<String> testList = new LinkedList<String>();
//			for(int k = 0; k <= N; k+= 1) {
//				String input = Integer.toString(k);
//				testList.addLast(input);
//			}
		
			startTime = System.nanoTime();
			for(int i = 0; i < timesToLoop; i++) {
				
				testList.remove(index);
			}
			
			midPointTime = System.nanoTime();
			
			//Experiment with adds to compensate for removes
			for (long j = 0; j < timesToLoop; j ++) {
			}
			
			stopTime = System.nanoTime();
			
			double averageTime = ((midPointTime - startTime) - (stopTime - midPointTime))/timesToLoop;
			
			System.out.println(N + "\t" + averageTime);
			
		}
		}
}


