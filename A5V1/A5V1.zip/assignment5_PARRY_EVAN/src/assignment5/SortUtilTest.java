package assignment5;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.jupiter.api.Test;

class SortUtilTest {

	
	@Test
	public void mergeSortTest() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>(5);
		testArr.add("Emily");
		testArr.add("Alice");
		testArr.add("David");
		testArr.add("Charles");
		testArr.add("Bethany");
		
		SortUtil.mergesort(testArr, cmp);
		
	}
	
	public class StringComparator implements Comparator<String>{
		public int compare(String o1, String o2){
			return o1.compareTo(o2);
		}
	}

}
