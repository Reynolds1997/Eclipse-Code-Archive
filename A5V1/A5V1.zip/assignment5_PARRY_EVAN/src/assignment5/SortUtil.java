package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class as specified in the assignment5 instructions.
 *
 */
public class SortUtil{
	
	public static <T> void mergesort(ArrayList<T> arr, Comparator<? super T> cmp) {
		ArrayList<T> temp = new ArrayList<T>(arr.size());
		
		mergeSortHelper(arr, temp, cmp, 0, arr.size()-1);
	}
	
	public static <T> void mergeSortHelper(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start, int end) {
		
		if(start >= end) {
			return;
		}
		
		int mid = start+((end - start)/2);
		
		mergeSortHelper(arr, tempArr, cmp, start, mid);
		mergeSortHelper(arr, tempArr, cmp, mid+1, end);
		
		merge(arr, tempArr, cmp, start, mid+1, end);
		
	}
	
	public static <T> void merge(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start, int mid, int end) {
		
		int subSize1 = mid - 1;
		
		//going from start to mid and mid to end
		
		int i = start;
		int j = mid;
		int k = mid;
		
		while(start <= subSize1 && mid <= end) {
			if(cmp.compare(arr.get(i), arr.get(j)) <= 0) {
				tempArr.set(i, arr.get(start));
				i++;
				start++;
			}
			else {
				tempArr.set(i, arr.get(mid));
				i++;
				mid++;
			}
			//k++;
		}
		
		while(start <= subSize1) {
			tempArr.set(i, arr.get(start));
			i++;
			start++;
			
		}
		while(mid <= end) {
			tempArr.set(i, arr.get(mid));
			i++;
			mid++;
		}
		
		arr = tempArr;
	}
		
}
