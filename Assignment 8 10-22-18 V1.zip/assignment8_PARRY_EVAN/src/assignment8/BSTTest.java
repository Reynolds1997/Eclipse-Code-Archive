package assignment8;

import java.io.PrintWriter;

import org.junit.jupiter.api.Test;

public class BSTTest {
	
	
	@Test
	public void testWrite() {
	
	BinarySearchTree<String> test = new BinarySearchTree<String>();

	boolean bool;
	bool = test.add("GutenTag");
	bool = test.add("Bonjour");
	bool = test.add("Bienvenue");
	bool = test.add("Salut");
	bool = test.add("Hello");
	
	test.writeDot("TestPrint02");
	}
	
}

