package assignment8;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.NoSuchElementException;

public class BinarySearchTree<T extends Comparable<? super T>> implements SortedSet<T> {

	BinaryNode root;

	public BinarySearchTree() {
		root = null;
	}

	@Override
	public boolean add(T item) { // Do we need to change T back to Comparable?
		// TODO Auto-generated method stub

		root = recursiveAdd(root, item);
		return true;
	}

	public BinaryNode recursiveAdd(BinaryNode node, T item) {
		BinaryNode parent = null;

		if (node == null) {
			if (parent == null) {
				return new BinaryNode(item);
			} else
				return new BinaryNode(item, parent);
		}

		if (item.compareTo(node.data) < 0) {
			parent = node;
			node.left = recursiveAdd(node.left, item);
		} else if (item.compareTo(node.data) > 0) {
			parent = node;
			node.right = recursiveAdd(node.right, item);
		} else {
			return node;
		}
		return node;
	}

	@Override
	public boolean addAll(Collection items) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
	}

	@Override
	public boolean contains(Comparable item) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection items) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T first() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T last() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(Comparable item) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection items) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList toArrayList() {
		// TODO Auto-generated method stub
		return null;
	}

	// YOU CAN USE THE BELOW PRIVATE CLASS AS YOUR NODE FOR ASSIGNMENT 8
	/**
	 * Represents a general binary tree node. Each binary node contains data, a left
	 * child, a right child, and a parent
	 * 
	 * This would make a good node class for a BinarySearchTree implementation
	 * 
	 */
	private class BinaryNode {

		// Since the outer BST class declares <T>, we can use it here without
		// redeclaring it for BinaryNode
		T data;

		BinaryNode left;

		BinaryNode right;

		BinaryNode parent;

		/**
		 * Construct a new node with a parent
		 */
		public BinaryNode(T _data, BinaryNode _parent) {
			data = _data;
			left = null;
			right = null;
			parent = _parent;
		}

		/**
		 * Construct a new node with no parent
		 */
		public BinaryNode(T item) {
			// Invoke the 2-parameter constructor with null parent
			this(item, null);
		}

	}
	
	// Driver for writing this tree to a dot file
	public void writeDot(String filename)
	{
		try {
			// PrintWriter(FileWriter) will write output to a file
			PrintWriter output = new PrintWriter(new FileWriter(filename));

			// Set up the dot graph and properties
			output.println("digraph BST {");
			output.println("node [shape=record]");

			if(root != null)
				writeDotRecursive(root, output);
			// Close the graph
			output.println("}");
			output.close();
		}
		catch(Exception e){e.printStackTrace();}
	}


	private void writeDotRecursive(BinaryNode n, PrintWriter output) throws Exception {
		output.println(n.data + "[label=\"<L> |<D> " + n.data + "|<R> \"]");
		if (n.left != null) {
			// write the left subtree
			writeDotRecursive(n.left, output);

			// then make a link between n and the left subtree
			output.println(n.data + ":L -> " + n.left.data + ":D");
		}
		if (n.right != null) {
			// write the left subtree
			writeDotRecursive(n.right, output);

			// then make a link between n and the right subtree
			output.println(n.data + ":R -> " + n.right.data + ":D");
		}

	}

}
