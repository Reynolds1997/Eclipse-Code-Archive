package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class as specified in the assignment5 instructions.
 *
 */
public class SortUtil {

	private static int threshold = 10;
	private static int pivot = 0;

	public static <T> void mergesort(ArrayList<T> arr, Comparator<? super T> cmp) {
		ArrayList<T> temp = new ArrayList<T>(arr.size());

//		for(int i = 0; i < arr.size(); i++) {
//			temp.add(null);
//		}

		mergeSortHelper(arr, temp, cmp, 0, arr.size() - 1);
	}

	public static <T> void mergeSortHelper(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start,
			int end) {

		if (start >= end) {
			return;
		}
		// Check if arr.size works too
		if ((end - start) <= threshold) {
			insertionSort(arr, cmp);
		} else {
			// This we trigger when dataset is greater than threshold
			int mid = (start + end) / 2;
			mergeSortHelper(arr, tempArr, cmp, start, mid);
			mergeSortHelper(arr, tempArr, cmp, mid + 1, end);
			tempArr.clear();
			merge(arr, tempArr, cmp, start, mid, end);
		}
	}

	public static <T> void merge(ArrayList<T> arr, ArrayList<T> temp, Comparator<? super T> cmp, int start, int mid,
			int end) {
		int i = start;
		int i2 = mid + 1;

		while ((i <= mid) && (i2 <= end)) {
			if (cmp.compare(arr.get(i), arr.get(i2)) <= 0) {
				temp.add(arr.get(i));
				i++;
			} else {
				temp.add(arr.get(i2));
				i2++;
			}
		}

		while (i <= mid) {
			temp.add(arr.get(i));
			i++;
		}

		while (i2 <= end) {
			temp.add(arr.get(i));
			i2++;
			i++;
		}

		int j = 0;
		int k = start;
		while (j < temp.size()) {
			arr.set(k, temp.get(j));
			j++;
			k++;
		}
	}

	public static <T> void insertionSort(ArrayList<T> arr, Comparator<? super T> cmp) {
		int stop = arr.size();
		int i;
		T key;
		int j;

		for (i = 1; i < stop; i++) {
			key = arr.get(i);
			j = i - 1;

			while (j >= 0 && cmp.compare(arr.get(j), key) > 0) {
				arr.set(j + 1, arr.get(j));
				j--;
			}
			arr.set(j + 1, key);
		}
	}

	// Quicksort

	public static <T> void quickSort(ArrayList<T> arr, Comparator<? super T> cmp) {

		// pick an item to be our pivot (via selecting its index) i.e. arr.get(mid)
		// Swap that with the last item

		// helpers
		// one that selects from the middle, one that selects from an end, and one
		// that's random(?)

		partition(arr, cmp, 0, arr.size() - 1);
	}

	public static <T> void partition(ArrayList<T> arr, Comparator<? super T> cmp, int leftBound, int rightBound) {

		int left = leftBound;
		int right = rightBound - 1;
		T pivot = arr.get(arr.size()-1);
		
		if (leftBound > rightBound)
			return;
		else {
			while (left <= right) {
				while ((left < rightBound) && ((cmp.compare(arr.get(left), pivot) <= 0))) {
					left++;
				}
				while ((right >= 0) && (cmp.compare(arr.get(right), pivot) >= 0)) {
					right--;
				}
			}
			if (left < right) {
				swapReferences(arr, left, right);
			}
			swapReferences(arr, left, rightBound);
		}

		partition(arr, cmp, leftBound, left - 1);
		partition(arr, cmp, left + 1, right);
	}

	public static <T> void swapReferences(ArrayList<T> arr, int left, int right) {
		T temp = arr.get(left);

		arr.set(left, arr.get(right));
		arr.set(right, temp);

	}
}
