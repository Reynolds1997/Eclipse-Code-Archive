package assignment5;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.jupiter.api.Test;

class SortUtilTest {

	
	@Test
	public void mergeSortTest() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>(5);
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");
		
		SortUtil.mergesort(testArr, cmp);
		
		for(int i = 0; i < testArr.size(); i++) {
			System.out.println(testArr.get(i));
		}
	}
	
	@Test
	public void insertionSortTest() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>(5);
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");
		
		SortUtil.insertionSort(testArr, cmp);
		
		System.out.println("Testing insertionSort: ");
		for(int i = 0; i < testArr.size(); i++) {
			System.out.println(testArr.get(i));
		}
	}
	
@Test
	public void quickSortTest() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>(5);
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");
		
		SortUtil.quickSort(testArr, cmp);
		
		System.out.println("Testing quickSort: ");
		for(int i = 0; i < testArr.size(); i++) {
			System.out.println(testArr.get(i));
		}
	}
	
	
	
	
	public class StringComparator implements Comparator<String>{
		public int compare(String o1, String o2){
			return o1.compareTo(o2);
		}
	}

}
