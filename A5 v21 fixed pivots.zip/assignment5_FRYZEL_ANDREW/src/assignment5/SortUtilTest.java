package assignment5;

import java.util.ArrayList;
import java.util.Comparator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;

class SortUtilTest {

	// duplicates
	// even and odd array amounts
	// decimals, negative numbers etc

	// Merge Sort
	@Test
	public void testMergeSortTestStrings() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();

		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");

		ArrayList<String> ans = new ArrayList<String>();
		ans.add("alice");
		ans.add("alice");

		ans.add("bethany");
		ans.add("bethany");

		ans.add("charles");
		ans.add("charles");
		ans.add("david");
		ans.add("david");
		ans.add("emily");
		ans.add("emily");

		SortUtil.mergesort(testArr, cmp);

		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(ans.get(i), testArr.get(i));

//			 //System.out.println(testArr.get(i));
//			 //System.out.println(testArr.size());
		}
	}

	@Test
	public void testMergeSortTestMoreStrings() {

		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emilyt");
		testArr.add("alicet");
		testArr.add("davidt");
		testArr.add("charles");
		testArr.add("bethanyt");
		testArr.add("emily");
		testArr.add("henry");
		testArr.add("kevin");
		testArr.add("george");
		testArr.add("fred");
		testArr.add("emilyd");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charlest");
		testArr.add("bethany");
		testArr.add("emilyr");
		testArr.add("henryt");
		testArr.add("kevint");
		testArr.add("georget");
		testArr.add("fredt");

		ArrayList<String> ans = new ArrayList<String>();
		ans.add("alice");
		ans.add("alicet");

		ans.add("bethany");
		ans.add("bethanyt");

		ans.add("charles");
		ans.add("charlest");

		ans.add("david");
		ans.add("davidt");

		ans.add("emily");
		ans.add("emilyd");
		ans.add("emilyr");
		ans.add("emilyt");

		ans.add("fred");
		ans.add("fredt");

		ans.add("george");
		ans.add("georget");

		ans.add("henry");
		ans.add("henryt");
		ans.add("kevin");
		ans.add("kevint");

		SortUtil.mergesort(testArr, cmp);

		// //System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));

			// //System.out.println(testArr.get(i));
		}
	}

//sortings from smallest to largest?
	@Test
	public void testMergeSortTestIntegers() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = new ArrayList<Integer>();

		testArr.add(6);
		testArr.add(1);
		testArr.add(42);
		testArr.add(23);
		testArr.add(5);
//sorting them by size not value
		ArrayList<Integer> ans = new ArrayList<Integer>();
		ans.add(1);
		ans.add(5);
		ans.add(6);
		ans.add(23);
		ans.add(42);

		SortUtil.mergesort(testArr, cmp);
		// ////System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			// System.out.println(testArr.get(i));
			assertEquals(testArr.get(i), ans.get(i));

		}
	}

	@Test
	public void testMergeSortTestMoreIntegers() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = new ArrayList<Integer>();
		testArr.add(4253654);
		testArr.add(546658);
		testArr.add(28546658);
		testArr.add(124253654);
		testArr.add(111201);
		testArr.add(3568465);

		testArr.add(2136);
		testArr.add(92136);
		testArr.add(28546658);

		testArr.add(124253654);

		testArr.add(4253654);
		testArr.add(5684652);

		testArr.add(568465);
		testArr.add(01);
		testArr.add(5684652);
		testArr.add(012);
		testArr.add(3568465);

		ArrayList<Integer> ans = new ArrayList<Integer>();

		ans.add(01);
		ans.add(012);
		ans.add(2136);
		ans.add(92136);
		ans.add(111201);
		ans.add(546658);
		ans.add(568465);

		ans.add(3568465);
		ans.add(3568465);
		ans.add(4253654);
		ans.add(4253654);
		ans.add(5684652);
		ans.add(5684652);
		ans.add(28546658);
		ans.add(28546658);
		ans.add(124253654);
		ans.add(124253654);

		SortUtil.insertionSort(testArr, cmp, 0, testArr.size() - 1);
		// //System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// System.out.println(testArr.get(i));
		}
	}

	// InsertionSort

	@Test
	public void insertionSortTestStrings() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charles");
		testArr.add("bethany");

		SortUtil.insertionSort(testArr, cmp, 0, testArr.size() - 1);

		ArrayList<String> ans = new ArrayList<String>();
		ans.add("alice");
		ans.add("bethany");
		ans.add("charles");
		ans.add("david");
		ans.add("emily");

		// ////System.out.println("Testing insertionSort: ");
		for (int i = 0; i < testArr.size() - 1; i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// //System.out.println(testArr.get(i));
		}
	}

	@Test
	public void testInsertionSortTestMoreStrings() {

		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emilyt");
		testArr.add("alicet");
		testArr.add("davidt");
		testArr.add("charles");
		testArr.add("bethanyt");
		testArr.add("emily");
		testArr.add("henry");
		testArr.add("kevin");
		testArr.add("george");
		testArr.add("fred");
		testArr.add("emilyd");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charlest");
		testArr.add("bethany");
		testArr.add("emilyr");
		testArr.add("henryt");
		testArr.add("kevint");
		testArr.add("georget");
		testArr.add("fredt");
		ArrayList<String> ans = new ArrayList<String>();
		ans.add("alice");
		ans.add("alicet");

		ans.add("bethany");
		ans.add("bethanyt");

		ans.add("charles");
		ans.add("charlest");

		ans.add("david");
		ans.add("davidt");

		ans.add("emily");
		ans.add("emilyd");
		ans.add("emilyr");
		ans.add("emilyt");

		ans.add("fred");
		ans.add("fredt");

		ans.add("george");
		ans.add("georget");

		ans.add("henry");
		ans.add("henryt");
		ans.add("kevin");
		ans.add("kevint");

		SortUtil.insertionSort(testArr, cmp, 0, testArr.size() - 1);

		// ////System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// //System.out.println(testArr.get(i));
		}
	}

	// Quick Sort
	@Test
	public void testQuickSortTestStrings() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("gregory");
		testArr.add("charles");
		testArr.add("bethany");
		testArr.add("frances");
		testArr.add("helen");

		ArrayList<String> ans = new ArrayList<String>();

		ans.add("alice");
		ans.add("bethany");
		ans.add("charles");
		ans.add("david");
		ans.add("emily");
		ans.add("frances");
		ans.add("gregory");
		ans.add("helen");

		SortUtil.quicksort(testArr, cmp);

		// ////System.out.println("Testing quickSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// ////System.out.println(testArr.get(i));
		}
	}

	@Test
	public void testQuickSortTestStringDuplicates() {
		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("gregory");
		testArr.add("charles");
		testArr.add("bethany");
		testArr.add("frances");
		testArr.add("helen");
		testArr.add("emily");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("gregory");
		testArr.add("charles");
		testArr.add("bethany");
		testArr.add("frances");
		testArr.add("helen");

		ArrayList<String> ans = new ArrayList<String>();

		ans.add("alice");
		ans.add("alice");
		ans.add("bethany");
		ans.add("bethany");
		ans.add("charles");
		ans.add("charles");
		ans.add("david");
		ans.add("david");
		ans.add("emily");
		ans.add("emily");
		ans.add("frances");
		ans.add("frances");
		ans.add("gregory");
		ans.add("gregory");
		ans.add("helen");
		ans.add("helen");
		ans.add("g");
		ans.add("g");

		SortUtil.quicksort(testArr, cmp);

		// ////System.out.println("Testing quickSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// ////System.out.println(testArr.get(i));
		}
	}

	@Test
	public void testQuickSortTestMoreStrings() {

		StringComparator cmp = new StringComparator();
		ArrayList<String> testArr = new ArrayList<String>();
		testArr.add("emilyt");
		testArr.add("alicet");
		testArr.add("davidt");
		testArr.add("charles");
		testArr.add("bethanyt");
		testArr.add("emily");
		testArr.add("henry");
		testArr.add("kevin");
		testArr.add("george");
		testArr.add("fred");
		testArr.add("emilyd");
		testArr.add("alice");
		testArr.add("david");
		testArr.add("charlest");
		testArr.add("bethany");
		testArr.add("emilyr");
		testArr.add("henryt");
		testArr.add("kevint");
		testArr.add("georget");
		testArr.add("fredt");

		ArrayList<String> ans = new ArrayList<String>();
		ans.add("alice");
		ans.add("alicet");

		ans.add("bethany");
		ans.add("bethanyt");

		ans.add("charles");
		ans.add("charlest");

		ans.add("david");
		ans.add("davidt");

		ans.add("emily");
		ans.add("emilyd");
		ans.add("emilyr");
		ans.add("emilyt");

		ans.add("fred");
		ans.add("fredt");

		ans.add("george");
		ans.add("georget");

		ans.add("henry");
		ans.add("henryt");
		ans.add("kevin");
		ans.add("kevint");

		SortUtil.quicksort(testArr, cmp);
		// ////System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// ////System.out.println(testArr.get(i));
		}
	}

//fix those
	@Test
	public void testQuickSortTestMoreIntegers() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = new ArrayList<Integer>();
		testArr.add(4253654);
		testArr.add(546658);

		testArr.add(111);
		testArr.add(3568465);

		testArr.add(2136);
		testArr.add(92136);
		testArr.add(28546658);

		testArr.add(124253654);

		testArr.add(568465);
		testArr.add(01);
		testArr.add(5684652);
		testArr.add(012);

		ArrayList<Integer> ans = new ArrayList<Integer>();

		ans.add(01);
		ans.add(012);
		ans.add(111);
		ans.add(2136);
		ans.add(92136);

		ans.add(546658);
		ans.add(568465);
		ans.add(3568465);
		ans.add(4253654);

		ans.add(5684652);

		ans.add(28546658);
		ans.add(124253654);

		SortUtil.quicksort(testArr, cmp);
		// //System.out.println("Testing mergeSort: ");
		for (int i = 0; i < testArr.size(); i++) {
			assertEquals(testArr.get(i), ans.get(i));
			// //System.out.println(testArr.get(i));
		}
	}

	@Test
	public void testNullMergeSort1() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = null;

		assertNull(testArr);

	}

	@Test
	public void testEmptyMergeSort() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = new ArrayList<Integer>(0);

		SortUtil.mergesort(testArr, cmp);
		assertEquals(0, testArr.size());

	}

	@Test
	public void testNullQuickSort() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = null;

		assertNull(testArr);

	}

	@Test
	public void testEmptyQuickSort() {
		IntegerComparator cmp = new IntegerComparator();
		ArrayList<Integer> testArr = new ArrayList<Integer>(10);

		SortUtil.quicksort(testArr, cmp);
		assertEquals(0, testArr.size());

	}
	// Need tests for our generator methods

	@Test
	public void testAverageCaseMergeSort() {

		int size = 10;
		ArrayList<Integer> testArr =SortUtil.generateAverageCase(size);
		
		for (int i = 0; i < testArr.size() - 1; i++) {
			System.out.println(testArr.get(i));
		}

		// testA

	}

	public class IntegerComparator implements Comparator<Integer> {

		@Override
		public int compare(Integer arg0, Integer arg1) {

			if (arg0.compareTo(arg1) < 0)
				return -1;

			if (arg0.compareTo(arg1) > 0)
				return 1;
			return 0;
		}

	}

	public class StringComparator implements Comparator<String> {
		public int compare(String o1, String o2) {

			return o1.compareTo(o2);
		}
	}

}
