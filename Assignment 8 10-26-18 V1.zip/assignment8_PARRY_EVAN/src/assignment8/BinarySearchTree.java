/**@author Evan Parry & Andrew Fryzel; starter code by Daniel Kopta  
 * Assignment 8: BinarySearchTree
 * Contains methods to create and operate a BinarySearchTree
 * CS2420-001
 */

package assignment8;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.NoSuchElementException;

public class BinarySearchTree<T extends Comparable<? super T>> implements SortedSet<T> {

	BinaryNode root;
	int size;

	public BinarySearchTree() {
		root = null;
		size = 0;
	}

	/**
	 * Ensures that this set contains the specified item.
	 * 
	 * @param item - the item whose presence is ensured in this set
	 * @return true if this set changed as a result of this method call (that is, if
	 *         the input item was actually inserted); otherwise, returns false
	 * @throws NullPointerException if the item is null
	 */
	@Override
	public boolean add(T item) { // Do we need to change T back to Comparable? Add the
									// Throws? need it?

		if (item == null) {
			throw new NullPointerException();
		}
		if (contains(item)) {

		} else {
			size++;
			root = recursiveAdd(root, item);

		}
		return true;
	}

	/**
	 * Ensures that this set contains all items in the specified collection.
	 * 
	 * @param items - the collection of items whose presence is ensured in this set
	 * @return true if this set changed as a result of this method call (that is, if
	 *         any item in the input collection was actually inserted); otherwise,
	 *         returns false
	 * @throws NullPointerException if any of the items is null
	 */
	@Override
	public boolean addAll(Collection<? extends T> items) {

		boolean flag = false;
		for (T t : items) {
			if (t == null) {
				throw new NullPointerException();
			}
			if (add(t) == true) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * Removes all items from this set. The set will be empty after this method
	 * call.
	 */
	@Override
	public void clear() {

		root = null;
		size = 0;
	}

	/**
	 * Determines if there is an item in this set that is equal to the specified
	 * item.
	 * 
	 * @param item - the item sought in this set
	 * @return true if there is an item in this set that is equal to the input item;
	 *         otherwise, returns false
	 * @throws NullPointerException if the item is null
	 */
	@Override
	public boolean contains(T item) {

		if (item == null) {
			throw new NullPointerException();
		}

		return containsRecursive(root, item);
	}

	// TODO
	private boolean containsRecursive(BinaryNode node, T item) {
		if (node == null) {
			return false;
		} else if (item.compareTo(node.data) == 0) {
			return true;
		} else if (item.compareTo(node.data) < 0) {
			return containsRecursive(node.left, item);
		}
		// if(item.compareTo(node.data) > 0)
		else {
			return containsRecursive(node.right, item);
		}
	}

	/**
	 * Determines if for each item in the specified collection, there is an item in
	 * this set that is equal to it.
	 * 
	 * @param items - the collection of items sought in this set
	 * @return true if for each item in the specified collection, there is an item
	 *         in this set that is equal to it; otherwise, returns false
	 * @throws NullPointerException if any of the items is null
	 */
	@Override
	public boolean containsAll(Collection<? extends T> items) {

		for (T t : items) {
			if (t == null) {
				throw new NullPointerException();
			}
			if (contains(t) == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns the first (i.e., smallest) item in this set.
	 * 
	 * @throws NoSuchElementException if the set is empty
	 */
	@Override
	public T first() throws NoSuchElementException {

		if (isEmpty()) {
			throw new NoSuchElementException();
		}

		BinaryNode node = root;

		while (node.left != null) {
			node = node.left;
		}
		return node.data;

	}

	/**
	 * Returns true if this set contains no items.
	 */
	@Override
	public boolean isEmpty() {

		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Returns the last (i.e., largest) item in this set.
	 * 
	 * @throws NoSuchElementException if the set is empty
	 */
	@Override
	public T last() throws NoSuchElementException{

		if (isEmpty()) {
			throw new NoSuchElementException();
		}

		BinaryNode node = root;

		while (node.right != null) {
			node = node.right;
		}
		return node.data;
	}

	// TODO
	private T smallestInSubTree(BinaryNode node) {
		while (node.left != null) {
			node = node.left;
		}
		return node.data;
	}

	// TODO
	private BinaryNode recursiveRemove(BinaryNode node, T item) {
		if (node == null) {
			return null;
		}

		if (item.compareTo(node.data) == 0) {
			if (node.left == null && node.right == null) {

				return null;
			}

			if (node.right == null) {

				return node.left;
			}

			if (node.left == null) {

				return node.right;
			}

			else {
				T data = smallestInSubTree(node.right);
				node.data = data;
				node.right = recursiveRemove(node.right, data);
			}

			return node;

		}

		if (item.compareTo(node.data) < 0) {
			node.left = recursiveRemove(node.left, item);
			return node;
		}

		node.right = recursiveRemove(node.right, item);
		return node;
	}

	/**
	 * Ensures that this set does not contain the specified item.
	 * 
	 * @param item - the item whose absence is ensured in this set
	 * @return true if this set changed as a result of this method call (that is, if
	 *         the input item was actually removed); otherwise, returns false
	 * @throws NullPointerException if the item is null
	 */
	@Override
	public boolean remove(T item) {

		if (item == null) {
			throw new NullPointerException();
		}

		else if (!(contains(item))) {

		} 
		else {
			size--;
			recursiveRemove(root, item);
			return true;
		}
		return false;
	}

	/**
	 * Ensures that this set does not contain any of the items in the specified
	 * collection.
	 * 
	 * @param items - the collection of items whose absence is ensured in this set
	 * @return true if this set changed as a result of this method call (that is, if
	 *         any item in the input collection was actually removed); otherwise,
	 *         returns false
	 * @throws NullPointerException if any of the items is null
	 */
	@Override
	public boolean removeAll(Collection<? extends T> items) {
		boolean flag = false;
		for (T t : items) {
			if (t == null) {
				throw new NullPointerException();
			}
			if (remove(t) == true) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * Returns the number of items in this set.
	 */
	@Override
	public int size() {

		return size;
	}

	/**
	 * Returns an ArrayList containing all of the items in this set, in sorted
	 * order.
	 */
	@Override
	public ArrayList<T> toArrayList() {

		ArrayList<T> list = new ArrayList<T>();

		return inOrderTraversal(root, list);
	}

	// TODO
	private ArrayList<T> inOrderTraversal(BinaryNode node, ArrayList<T> arr) {

		if (node != null) {
			inOrderTraversal(node.left, arr);
			arr.add(node.data);
			inOrderTraversal(node.right, arr);
		}

		return arr;
	}

	// YOU CAN USE THE BELOW PRIVATE CLASS AS YOUR NODE FOR ASSIGNMENT 8
	/**
	 * Represents a general binary tree node. Each binary node contains data, a left
	 * child, a right child, and a parent
	 * 
	 * This would make a good node class for a BinarySearchTree implementation
	 * 
	 */
	// TODO
	private class BinaryNode {

		// Since the outer BST class declares <T>, we can use it here without
		// redeclaring it for BinaryNode
		T data;

		BinaryNode left;

		BinaryNode right;

		BinaryNode parent;

		/**
		 * Construct a new node with a parent
		 */
		public BinaryNode(T _data, BinaryNode _parent) {
			data = _data;
			left = null;
			right = null;
			parent = _parent;
		}

		/**
		 * Construct a new node with no parent
		 */
		public BinaryNode(T item) {
			// Invoke the 2-parameter constructor with null parent
			this(item, null);
		}

	}

	// TODO
	private BinaryNode recursiveAdd(BinaryNode node, T item) {
		BinaryNode parent = null;

		if (node == null) {
			if (parent == null) {

				return new BinaryNode(item);
			}
		}

		if (item.compareTo(node.data) == 0) {

			return node;

		} else if (item.compareTo(node.data) < 0) {
			parent = node;
			node.left = recursiveAdd(node.left, item);
		} else if (item.compareTo(node.data) > 0) {
			parent = node;
			node.right = recursiveAdd(node.right, item);
		}

		return node;
	}

	// TODO
	// Driver for writing this tree to a dot file
	public void writeDot(String filename) {
		try {
			// PrintWriter(FileWriter) will write output to a file
			PrintWriter output = new PrintWriter(new FileWriter(filename));

			// Set up the dot graph and properties
			output.println("digraph BST {");
			output.println("node [shape=record]");

			if (root != null)
				writeDotRecursive(root, output);
			// Close the graph
			output.println("}");
			output.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// TODO
	private void writeDotRecursive(BinaryNode n, PrintWriter output) throws Exception {
		output.println(n.data + "[label=\"<L> |<D> " + n.data + "|<R> \"]");
		if (n.left != null) {
			// write the left subtree
			writeDotRecursive(n.left, output);

			// then make a link between n and the left subtree
			output.println(n.data + ":L -> " + n.left.data + ":D");
		}
		if (n.right != null) {
			// write the left subtree
			writeDotRecursive(n.right, output);

			// then make a link between n and the right subtree
			output.println(n.data + ":R -> " + n.right.data + ":D");
		}

	}

}
