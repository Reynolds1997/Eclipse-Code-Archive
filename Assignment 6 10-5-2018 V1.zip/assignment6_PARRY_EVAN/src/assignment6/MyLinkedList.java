/**@author Evan Parry & Andrew Fryzel; starter code by Daniel Kopta  
 * Assignment 6: MyLinkedList
 * CS2420-001
 */

package assignment6;

import java.util.NoSuchElementException;

public class MyLinkedList<T> implements List<T> {

	private Node head = null;
	private Node tail = null;
	private int size = 0;

	/**
	 * A private class that defines a LinkedList node. Nodes contain a data element
	 * and links to the next and previous nodes in the list.
	 *
	 */
	private class Node {

		T element;
		Node next;
		Node previous;

		Node(T data) {
			element = data;
			next = null;
			previous = null;
		}
	}

	/**
	 * Basic constructor, called to create a LinkedList with the default head, tail,
	 * and size values.
	 */
	public MyLinkedList() {
		
	}

	/**
	 * Returns a reference to the node at a specified index. 
	 * 
	 * @param index
	 * @return the node at the specified index
	 */
	public Node getNode (int index) throws IndexOutOfBoundsException{
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		
		Node curr;
		if (index < (size / 2)) {
			curr = head;
			for (int i = 0; i < index; i++) {
				curr = curr.next;
			}
		} else {
			curr = tail;
			for (int j = size - 1; j > index; j--) {
				curr = curr.previous;
			}
		}
		return curr;
	}
	
	/**
	 * Inserts the specified element at the beginning of the list.
	 * O(1) for a doubly-linked list.
	 * 
	 * @param element
	 */
	@Override
	public void addFirst(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size > 0) {
			newNode.next = head;
			head.previous = newNode;
		}

		else if (size == 0) {
			tail = newNode;
		}

		// Make sure that the new head's .previous is pointing to null
		head = newNode;
		newNode.previous = null;

		size++;
	}

	/**
	 * Inserts the specified element at the end of the list.
	 * O(1) for a doubly-linked list.
	 * 
	 * @param element
	 */
	@Override
	public void addLast(T element) {
		// TODO Auto-generated method stub

		Node newNode = new Node(element);

		if (size == 0) {
			addFirst(element);
		} else {
			newNode.previous = tail;
			tail.next = newNode;

			// Make sure that the new tail's .next is pointing to null

			tail = newNode;
			newNode.next = null;
			size++;
		}
	}

	
	/**
	 * Inserts the specified element at the specified position in the list.
	 * Throws IndexOutOfBoundsException if index is out of range (index < 0 || index > size())
	 * O(N) for a doubly-linked list.
	 * 
	 * @param index
	 * @param element
	 */
	@Override
	public void add(int index, T element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}

		if (index == 0) {
			addFirst(element);
		}
		else if (index == size) {
			addLast(element);
		}
		else {

		Node newNode = new Node(element);

		Node curr = getNode(index);
		
		newNode.previous = curr.previous;
		newNode.next = curr;
		curr.previous.next = newNode;
		curr.previous = newNode;

		size++;
		}
	}

	/**
	 * Returns the first element in the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 * 
	 * @return the first element in the list.
	 */
	@Override
	public T getFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return head.element;
	}

	/**
	 * Returns the last element in the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 * 
	 * @return the last element in the list.
	 */
	@Override
	public T getLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return tail.element;
	}

	/**
	 * Returns the element at the specified position in the list.
	 * Throws IndexOutOfBoundsException if index is out of range (index < 0 || index >= size())
	 * O(N) for a doubly-linked list.
	 * 
	 * @param index
	 * @return the element at the specified index
	 */
	@Override
	public T get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}

		Node curr = getNode(index);
		return curr.element;
	}

	/**
	 * Removes and returns the first element from the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 * 
	 * @return the first element in the list.
	 */
	@Override
	public T removeFirst() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		Node tempHead = head;
		head.next = head;
		head.previous = null;
		size--;
		return tempHead.element;
	}

	/**
	 * Removes and returns the last element from the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 * 
	 * @return the last element in the list.
	 */
	@Override
	public T removeLast() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if (size == 0) {
			throw new NoSuchElementException();
		}
		Node tempTail = tail;
		tail.previous = tail;
		tail.next = null;
		size--;
		return tempTail.element;
		
	}

	/**
	 * Removes and returns the element at the specified position in the list.
	 * Throws IndexOutOfBoundsException if index is out of range (index < 0 || index >= size())
	 * O(N) for a doubly-linked list.
	 * 
	 * @param index
	 * @return the element at the specified index.
	 */
	@Override
	public T remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			return removeFirst();
		}
		else if (index == size - 1) {
			return removeLast();
		}
		else {
		Node removeNode = getNode(index);
		
		removeNode.previous.next = removeNode.next;
		removeNode.next.previous = removeNode.previous;
		size--;
		return removeNode.element;
		}
	}

	/**
	 * Returns the index of the first occurrence of the specified element in the list, 
	 * or -1 if this list does not contain the element.
	 * O(N) for a doubly-linked list.
	 * 
	 * @param element
	 * @return the index of the element's first occurrence. Returns -1 if the element 
	 * cannot be found.
	 */
	@Override
	public int indexOf(T element) {
		// TODO Auto-generated method stub
		
		Node temp = head;

		for (int i = 0; i < size; i++) {
			if (temp.element.equals(element)) {
				return i;
			}
			temp = temp.next;
		}
		return -1;
	}

	/**
	 * Returns the index of the last occurrence of the specified element in this list, 
	 * or -1 if this list does not contain the element.
	 * O(N) for a doubly-linked list.
	 * 
	 * @param element
	 * @return the index of the element's last occurrence. Returns -1 if the element 
	 * cannot be found.
	 */
	@Override
	public int lastIndexOf(T element) {
		// TODO Auto-generated method stub
		Node temp = tail;
		
		for (int i = size - 1; i >= 0; i--) {
			if (temp.element.equals(element)) {
				return i;
			}
			temp = temp.previous;
		}
		return -1;
	}

	/**
	 * Returns the number of elements in this list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	/**
	 * Returns true if this collection contains no elements.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (size == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Removes all of the elements from this list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		head = null;
		tail = null;
		size = 0;
	}

	/**
	 * Returns an array containing all of the elements in this list in proper sequence 
	 * (from first to last element).
	 * O(N) for a doubly-linked list.
	 * 
	 * @return an Object array representation of the list's elements.
	 */
	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		Object[] newArray = new Object[size+1];
		
		Node temp = head;
		for(int i = 0; i < size; i ++) {
			newArray[i] = temp.element;
			temp = temp.next;
		}
		
		return newArray;
	}

}
