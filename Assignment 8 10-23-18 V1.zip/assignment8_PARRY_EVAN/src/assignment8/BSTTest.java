package assignment8;

import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class BSTTest {
	

	
	@Test
	public void testWrite() {
	
	BinarySearchTree<String> test = new BinarySearchTree<String>();

	boolean bool;
	bool = test.add("Grace");
	bool = test.add("Alice");
	bool = test.add("Charlie");
	bool = test.add("Agatha");
	bool = test.add("Zachary");
	bool = test.add("Alice");
	bool = test.add("Jennifer");

	test.writeDot("10-23-2018 Test01");
	}
	
	@Test 
	public void testRemove() {
		
	BinarySearchTree<String> test = new BinarySearchTree<String>();

	boolean bool;
	bool = test.add("Grace");
	bool = test.add("Alice");
	bool = test.add("Charlie");
	bool = test.add("Agatha");
	bool = test.add("Zachary");
	bool = test.add("Alice");
	bool = test.add("Jennifer");
	bool = test.remove("Alice");
	bool = test.remove("Jennifer");
	
	test.writeDot("10-23-2018 Test02");
	}
	
	@Test
	public void testClear() {
		
		BinarySearchTree<String> test = new BinarySearchTree<String>();

		boolean bool;
		bool = test.add("Grace");
		bool = test.add("Alice");
		bool = test.add("Charlie");
		bool = test.add("Agatha");
		
		System.out.println("Is empty: " + test.isEmpty());
		test.clear();
		System.out.println("Is empty: " + test.isEmpty());
	}
	
	@Test
	public void testContains() {
		
		BinarySearchTree<String> test = new BinarySearchTree<String>();

		boolean bool;
		bool = test.add("Grace");
		bool = test.add("Alice");
		bool = test.add("Charlie");
		bool = test.add("Agatha");
		
		System.out.println("Contains Agatha: " + test.contains("Agatha"));
		System.out.println("Contains Christie: " + test.contains("Christie"));
	}
	
	@Test
	public void testLeftRight() {
	
	BinarySearchTree<String> test = new BinarySearchTree<String>();

	boolean bool;
	bool = test.add("Grace");
	bool = test.add("Alice");
	bool = test.add("Charlie");
	bool = test.add("Agatha");
	bool = test.add("Zachary");
	bool = test.add("Alice");
	bool = test.add("Jennifer");

	System.out.println("First is: " + test.first());
	System.out.println("Last is: " + test.last());
	}
	
	@Test
	public void testToArray() {
	
	BinarySearchTree<String> test = new BinarySearchTree<String>();

	boolean bool;
	bool = test.add("Grace");
	bool = test.add("Alice");
	bool = test.add("Charlie");
	bool = test.add("Agatha");
	bool = test.add("Zachary");
	bool = test.add("Alice");
	bool = test.add("Jennifer");

	ArrayList<String> testArray = test.toArrayList();
	System.out.println("Test Array: " + testArray.toString());
	}
}

