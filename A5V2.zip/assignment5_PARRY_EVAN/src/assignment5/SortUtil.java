package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * 
 * @author ?? Fill in this class as specified in the assignment5 instructions.
 *
 */
public class SortUtil{
	
	public static <T> void mergesort(ArrayList<T> arr, Comparator<? super T> cmp) {
		ArrayList<T> temp = new ArrayList<T>(arr.size());
		
		for(int i = 0; i < arr.size(); i++) {
			temp.add(null);
		}
		
		mergeSortHelper(arr, temp, cmp, 0, arr.size()-1);
	}
	
	public static <T> void mergeSortHelper(ArrayList<T> arr, ArrayList<T> tempArr, Comparator<? super T> cmp, int start, int end) {
		
		if(start >= end) {
			return;
		}
		
		int mid = (start + end)/2;
		
		mergeSortHelper(arr, tempArr, cmp, start, mid);
		mergeSortHelper(arr, tempArr, cmp, mid+1, end);
		
		merge(arr, tempArr, cmp, start, mid + 1, end);
		
	}
	
	public static <T> void merge(ArrayList<T> arr, ArrayList<T> temp, Comparator<? super T> cmp, int start, int mid, int end) {
		
		int i1 = 0;  
		int i2 = mid;
		
		while(i1 < mid && i2 < end) {
			if(cmp.compare(arr.get(i1), arr.get(i2)) <= 0){
				temp.add(arr.get(i1));
				i1++;
			}
			else {
				temp.add(arr.get(i2));
				i2++;
			}
		}
		
		while(i1 < mid) {
			temp.add(arr.get(i1));
		}
		while(i2< end) {
			temp.add(arr.get(i2));
		}
		
		for(int i = 0; i < temp.size(); i++){
			System.out.println("Temp at " + i + " is " + temp.get(i));
		}
		//for(int j = 0; j )
	}
		
}


//while(start <= i2 && mid <= end) {
//	if(cmp.compare(arr.get(start), arr.get(mid))<=0){
//		temp.set(i1, arr.get(start));
//		start++;
//		i1++;
//	}
//	else {
//		temp.set(i1, arr.get(mid));
//		mid++;
//		i1++;
//	}
//}
//
//while(start <= i2) {
//temp.set(i1, arr.get(start));
//i1++;
//start++;
//}
//
//while(mid <= end) {
//temp.set(i1, arr.get(mid));
//i1++;
//mid++;
//}
//
//for(int i = 0; i < temp.size(); i++){
//System.out.println("Temp at " + i + " is " + temp.get(i));
//}


//while(start <= subSize1 && mid <= end) {
//	if(cmp.compare(arr.get(i), arr.get(j)) <= 0) {
//		tempArr.set(i, arr.get(start));
//		i++;
//		start++;
//	}
//	else {
//		tempArr.set(i, arr.get(mid));
//		i++;
//		mid++;
//	}
//	//k++;
//}
//
//while(start <= subSize1) {
//	tempArr.set(i, arr.get(start));
//	i++;
//	start++;
//	
//}
//while(mid <= end) {
//	tempArr.set(i, arr.get(mid));
//	i++;
//	mid++;
//}
//
//arr = tempArr;

//int n1 = mid - start +1;
//int n2 = end - mid;
//
//ArrayList<T> left = new ArrayList<T>(n1);
//ArrayList<T> right = new ArrayList<T>(n2);
//
//for(int i = 0; i < n1; i++) {
//	left.set(i, arr.get(start+i));
//}
//for(int j = 0; j < n2; j++) {
//	right.set(j, arr.get(mid + 1 + j));
//}
//
//int i = 0;
//int j = 0;
//
//int k = start;
//
//while(i < n1 && j < n2) {
//	if(cmp.compare(left.get(i), right.get(j)) <= 0) {
//		arr.set(k, left.get(i));
//		i++;
//	}
//	else {
//		arr.set(k, right.get(j));
//		j++;
//	}
//}
//
//while(i < n1) {
//	arr.set(k, left.get(i));
//	i++;
//	k++;
//}
//
//while(j < n2) {
//	arr.set(k, right.get(j));
//	j++;
//	k++;
//}
