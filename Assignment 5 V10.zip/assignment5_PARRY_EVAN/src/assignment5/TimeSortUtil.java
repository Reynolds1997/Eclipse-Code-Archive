package assignment5;

import java.util.ArrayList;
import java.util.Comparator;

public class TimeSortUtil{
	
	public static void main(String[] args) {
		
		IntegerComparator cmp = new IntegerComparator();
		long midPointTime;
		long startTime = System.nanoTime();
		while(System.nanoTime() - startTime < 100000){
		}
		
		long stop = 0;
		long start = 0;
		
		//Lowered timesToLoop, raised maximum N. This gives us 100 data points in a matter of minutes.
		int timesToLoop = 2500;
		
		for(int N = 100; N <= 10000; N+=100) {
			int size = N;
			
			int total = 0;
			
			startTime = System.nanoTime();
			for (int j = 0; j <= timesToLoop; j++) {
				
				//Change this
				ArrayList<Integer> testArr = SortUtil.generateAverageCase(size);
				
				ArrayList<Integer> temp = new ArrayList<>();
				for(int i = 0; i < testArr.size(); i++) {
					temp.add(testArr.get(i));
				}
				
				
				
				//Change this
				SortUtil.quickSort(testArr, cmp);
				
			}
			
			midPointTime = System.nanoTime();
			for(int k = 0; k <= timesToLoop; k++) {
				//This line hopefully lets us subtract the array generation time from the total
				//testing time
				ArrayList<Integer> testArr = SortUtil.generateAverageCase(size);

			}

			//Moved stop and midpoint to their proper locations so that the formula for average time
			//will calculate properly
			stop = System.nanoTime();

		
			total += stop - start;
			
			double averageTime = ((midPointTime - startTime) - (stop - midPointTime))/timesToLoop;
			
			System.out.println(size + "\t" + averageTime);
			
			
		}
	}
}

class IntegerComparator implements Comparator<Integer>{
	
	@Override
	public int compare(Integer arg0, Integer arg1) {
		return(arg0.compareTo(arg1));
	}
}